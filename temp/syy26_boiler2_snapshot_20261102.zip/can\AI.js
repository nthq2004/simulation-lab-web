/**
 * AI.js — 模拟量输入模块 (Analog Input Module) · 主入口
 * 船舶机舱监测报警系统 · CAN 总线架构
 *
 * 硬件规格：
 *   - 2路 4-20mA 电流输入 (CH1, CH2)
 *   - 1路 RTD 热电阻输入 (PT100)
 *   - 1路 TC 热电偶输入 (K型)
 *   - 2路 CAN 总线接口 (CANH / CANL)
 *   - DC 24V 电源接口
 *   - 4路通道运行指示灯 (每通道1个)
 *   - 4个模块状态指示灯：PWR / RUN / FLT / COM
 *   - 4位地址码拨码开关 (SW1~SW4，二进制编码，地址范围 0-15)
 *   - 1个终端电阻使能开关 (120Ω)
 *
 * 模块拆分说明：
 *   AI.constants.js  — 常量、通道配置、默认数据工厂函数
 *   AI.visuals.js    — Konva 图形绘制 Mixin（_initVisuals、_render 等）
 *   AI.can.js        — CAN 总线通信 Mixin（onCanReceive、_canTransmit 等）
 *   AI.js            — 主类（构造、主循环、通道数据处理、公开 API）
 */

import { BaseComponent } from '../components/BaseComponent.js';
import { NMT_STATE, CAN_TICK_INTERVAL } from './CANBUS.js';

import { W, H, CH_CONFIG, defaultChannels, defaultRanges, defaultAlarms } from './dpu/AI.constants.js';
import { applyVisualsMixin } from './dpu/AI.visuals.js';
import { applyCANMixin }     from './dpu/AI.can.js';

// ─────────────────────────────────────────────
//  主类定义
// ─────────────────────────────────────────────
export class AIModule extends BaseComponent {
    /**
     * @param {Object} config - 初始化配置对象（可选）
     * @param {Object} sys    - 系统环境对象（仿真引擎）
     */
    constructor(config, sys) {
        super(config, sys);

        this.w     = W;
        this.h     = H;
        this.scale = 1.1;
        this.type  = 'AI';
        this.special = 'can';
        this.cache   = 'fixed';  // 模板：静态部件仅 _staticGroup 做一次位图缓存，运行时不再刷新

        // ── 电源 / 物理连接状态 ──
        this.powerOn      = false;
        this.busConnected = false;

        // ── 5种故障状态 ──
        this.isBreak     = false;
        this.commFault   = false;
        this.moduleFault = false;
        this.channelFault = false;
        this.sysFault    = false;

        // ── 节点地址 (0~15)，由拨码开关决定 ──
        this.nodeAddress = 1;   // 默认地址，config 覆盖由 _initParameters() 读入

        // ── 终端电阻 ──
        this.termEnabled      = false;
        this.currentResistance = 1000000;

        // ── 通道数据 ──
        this.channels = defaultChannels();
        this.ranges   = defaultRanges();
        this.alarms   = defaultAlarms();

        // ── 模块状态灯 ──
        this.ledStatus = { pwr: false, run: false, flt: false, com: false };

        // ── CAN 总线状态 ──
        this.canBusConnected = false;
        this.lastTxTime  = 0;
        this.lastRxTime  = 0;
        this.txCount     = 0;
        this.rxCount     = 0;
        this.txInterval  = 200;   // ms
        this.comErrorCount = 0;

        // ── 内部计时 ──
        this._runBlink  = false;
        this._comBlink  = false;
        this._blinkTick = 0;

        // ── NMT 网络管理状态机 ──
        this.nmtState       = 'init';
        this.nmtStateTime   = Date.now();
        this._lastHeartbeat = 0;
        this.heartbeatTimeout = 10000;  // ms，可通过 config 覆盖

        // ── 新组件模板：固定调用顺序 ──
        this._initGroups();              // 静态 / 动态 / 交互 分组
        this._adoptGroups();             // 三组挂进 scaleGroup（本组件按 1.1 倍缩放）
        this._recalcGeometry();          // 计算几何尺寸
        this._initParameters(config);    // 参数读入 + config 副本
        this._init();                    // 静态绘制 → 动态节点 → 交互绑定
        this._initPorts();               // 最后注册端口
        this._startLoop();
    }

    /** 模板：几何尺寸计算 */
    _recalcGeometry() {
        this.width = W;
        this.height = H;
    }

    /** 模板：参数初始化（用 config 覆盖默认值，并保存 config 副本） */
    _initParameters(config) {
        if (config) {
            if (config.nodeAddress != null) this.nodeAddress = config.nodeAddress;
            if (config.termEnabled != null) this.termEnabled = !!config.termEnabled;
            if (config.heartbeatTimeout != null) this.heartbeatTimeout = config.heartbeatTimeout;
        }
        this.config = {
            nodeAddress: this.nodeAddress,
            termEnabled: this.termEnabled,
            heartbeatTimeout: this.heartbeatTimeout,
        };
    }

    /** 模板：可配置参数列表（供右键「参数设置」使用） */
    getConfigFields() {
        return [
            { key: 'nodeAddress', label: '节点地址(0~15)', min: 0, max: 15, step: 1 },
            { key: 'termEnabled', label: '终端电阻 120Ω', type: 'boolean' },
        ];
    }

    /** 模板：配置更新回调 */
    onConfigUpdate(cfg) {
        if (!cfg) return;
        if (cfg.nodeAddress != null) {
            this.nodeAddress = Math.max(0, Math.min(15, Number(cfg.nodeAddress) || 0));
            this._refreshSwitches && this._refreshSwitches();
            this._nodeAddrDisplay && this._nodeAddrDisplay.text(`NODE:${String(this.nodeAddress).padStart(2, '0')}`);
        }
        if (cfg.termEnabled != null) {
            this.termEnabled = !!cfg.termEnabled;
            this.currentResistance = this.termEnabled ? 120 : 1000000;
            if (this._termKnob) {
                this._termKnob.fill(this.termEnabled ? '#00aaff' : '#333');
            }
        }
        Object.assign(this.config || {}, { nodeAddress: this.nodeAddress, termEnabled: this.termEnabled });
        this.markDirty();
        this._refreshIfDirty(true);
    }

    // ══════════════════════════════════════════
    //  接线端口注册
    // ══════════════════════════════════════════
    _initPorts() {
        // 左侧：4路模拟输入，每路 + / -
        CH_CONFIG.forEach((ch, i) => {
            const yBase = 44 + i * 52;
            this.addPort(-18 * this.scale, (yBase + 12) * this.scale, `${ch.id}p`, 'wire', 'p');
            this.addPort(-18 * this.scale, (yBase + 38) * this.scale, `${ch.id}n`, 'wire');
        });
        // 右侧：24V 电源
        this.addPort((W + 18) * this.scale, 10 * this.scale, 'vcc', 'wire', 'p');
        this.addPort((W + 18) * this.scale, 38 * this.scale, 'gnd', 'wire');
        // 底部：CAN 总线
        this.addPort(35  * this.scale, (H + 20) * this.scale, 'can1p', 'wire', 'p');
        this.addPort(80  * this.scale, (H + 20) * this.scale, 'can1n', 'wire');
        this.addPort(125 * this.scale, (H + 20) * this.scale, 'can2p', 'wire', 'p');
        this.addPort(170 * this.scale, (H + 20) * this.scale, 'can2n', 'wire');
    }

    // ══════════════════════════════════════════
    //  交互（双击重置通信错误计数）
    // ══════════════════════════════════════════
    _initInteraction() {
        this.scaleGroup.on('dblclick', () => {
            this.comErrorCount = 0;
            this.markDirty();
            this._refreshIfDirty(true);
        });
    }

    // ══════════════════════════════════════════
    //  主循环：由 consys._tickAll 集中调用 tick(dt)，累计 CAN_TICK_INTERVAL 执行一次（10Hz）
    // ══════════════════════════════════════════
    _startLoop() {
        this._tickAcc     = 0;
        this.nmtState     = NMT_STATE.INIT;
        this.nmtStateTime = Date.now();
    }

    /** 集中式 tick（20fps 调用）：累计到 CAN_TICK_INTERVAL(100ms) 再执行原 _tick，保持 10Hz 更新频率 */
    tick(dt) {
        this._tickAcc = (this._tickAcc || 0) + dt;
        if (this._tickAcc < CAN_TICK_INTERVAL / 1000) return;
        this._tickAcc = 0;
        try {
            this.powerOn      = !this.isBreak &&
                this.sys.getVoltageBetween(`${this.id}_wire_vcc`, `${this.id}_wire_gnd`) > 18;
            this.busConnected = this.sys.isOnCanBus(`${this.id}_wire_can1p`) &&
                this.sys.isOnCanBus(`${this.id}_wire_can1n`);
        } catch (_) { }
        this._tick();
        // 每个 10Hz 周期结束刷新：清除 cache=false 组件可能残留的固化位图并请求重绘，
        // 否则模块状态/故障指示不会随节点更新显示出来（表现为"点一下才刷新"）
        this.markDirty();
        this._refreshIfDirty();
    }

    _tick() {
        const now = Date.now();
        this._blinkTick = now;

        // 1. 断电 → 黑屏
        if (!this.powerOn) {
            this._renderOff();
            return;
        }

        // 2. 电源灯常亮
        this.ledStatus.pwr = true;

        // 3. sysFault（死机）：停止工作
        if (this.sysFault) {
            this.ledStatus.run = false;
            this.ledStatus.flt = true;
            this.ledStatus.com = false;
            this._render();
            return;
        }

        // 4. 心跳超时：RUN → PREOP
        if (now - this._lastHeartbeat > this.heartbeatTimeout && this.nmtState === NMT_STATE.RUN) {
            this.nmtState     = NMT_STATE.PREOP;
            this.nmtStateTime = now;
            console.log(`[AI #${this.nodeAddress}] Heartbeat lost → ${NMT_STATE.PREOP} state`);
        }

        // 5. RUN 灯（每 500ms 闪烁）
        this._runBlink     = (now % 1000) < 500;
        this.ledStatus.run = this._runBlink;

        // 6. 通道数据处理
        this._processChannels();

        // 7. CAN 定时上报
        if (this._isCanTransmit() && now - this.lastTxTime >= this.txInterval) {
            this._canTransmit();
            this.lastTxTime = now;
        }

        // COM 灯：最近有 CAN 收发活动时按 1Hz 闪烁，无活动/断线/故障时熄灭。
        // 原实现用「TX 后 80ms 点亮」的窄窗口绑死 TX 时刻，AI/DI 因 txInterval
        // 较小而每次都落在窗口内 → 灯恒亮不闪；AO/DO 则相反。改为固定占空比后
        // 四个模块行为统一、且节拍与模块上报周期无关。
        const comActive = (now - Math.max(this.lastTxTime || 0, this.lastRxTime || 0)) < 1500;
        this._comBlink = comActive && ((now % 600) < 300);
        this.ledStatus.com = (!this.busConnected || this.commFault) ? false : this._comBlink;

        // 9. FLT 灯
        this.ledStatus.flt = this.moduleFault || this.commFault || this.sysFault||!this.busConnected;

        if (this.powerOn&&this.busConnected && !this.commFault) this.sys.canBus.setNodeOnline(this.id);
        else                                       this.sys.canBus.resetNodeOnline(this.id);

        // 10. 渲染
        this._render();
    }

    // ══════════════════════════════════════════
    //  通道数据处理（ADC 转换 + 报警判断）
    // ══════════════════════════════════════════
    _processChannels() {
        // moduleFault：所有通道失效
        if (this.moduleFault) {
            Object.keys(this.channels).forEach(id => {
                this.channels[id].fault     = true;
                this.channels[id].faultText = 'OPEN';
                this.channels[id].value     = -1;
            });
            return;
        }

        Object.keys(this.channels).forEach(id => {
            const ch  = this.channels[id];
            const rng = this.ranges[id];
            const alm = this.alarms[id];

            // channelFault：仅 ch1 失效
            if (this.channelFault && id === 'ch1') {
                ch.fault = true; ch.faultText = 'OPEN'; ch.value = -1;
                return;
            }

            // ── ADC 转换 ──
            switch (ch.type) {
                case '4-20mA':
                    if (ch.raw < 3.8 || ch.raw > 20.5) {
                        ch.fault = true;
                        ch.faultText = ch.raw < 0.1 ? 'OPEN' : ch.raw > 21 ? 'SHORT' : 'OUTRANGE';
                    } else {
                        ch.fault = false;
                        ch.value = rng.lrv + ((ch.raw - 4) / 16) * (rng.urv - rng.lrv);
                    }
                    break;

                case 'RTD': {
                    const r = ch.raw;
                    if (r < 18.52 || r > 175.86) {
                        ch.fault = true;
                        ch.faultText = ch.raw < 0.5 ? 'SHORT' : ch.raw > 1000 ? 'OPEN' : 'OUTRANGE';
                        ch.value = ch.raw < 0.5 ? rng.lrv : rng.urv;  // 故障时设为限制值
                    } else {
                        ch.fault = false;
                        const val = (r / 100 - 1) / 0.00385;  // PT100 线性近似
                        ch.value = isFinite(val) ? val : 0;   // NaN 保护
                    }
                    break;
                }
                case 'TC': {
                    const mv = ch.raw;
                    if (mv < -10 || mv > 100.0) {
                        ch.fault = true;
                        ch.faultText = ch.raw < -10 ? 'OPEN' : 'OUTRANGE';
                    } else {
                        ch.fault = false;
                        ch.value = mv / 0.041;  // K型热电偶线性近似
                    }
                    break;
                }
            }

            // 限幅（超量程不故障但截断）
            if (!ch.fault) {
                const margin = (rng.urv - rng.lrv) * 0.05;
                const val = ch.value;
                ch.value = isFinite(val) ? Math.max(rng.lrv - margin, Math.min(rng.urv + margin, val)) : 0;
            } else if (!isFinite(ch.value)) {
                ch.value = 0;  // 故障时若值仍为 NaN，设为 0
            }

            // ── 报警判断 ──
            if (!ch.fault) {
                const v = ch.value;
                if      (v >= alm.hh) alm.status = 'HH';
                else if (v >= alm.hh)  alm.status = 'H';
                else if (v <= alm.ll) alm.status = 'LL';
                else if (v <= alm.ll)  alm.status = 'L';
                else                  alm.status = 'normal';
            } else {
                alm.status = 'FAULT';
            }
        });
    }

    // ══════════════════════════════════════════
    //  公开 API（供仿真引擎调用）
    // ══════════════════════════════════════════

    /**
     * 注入原始信号值
     * @param {string} chId - 'ch1' | 'ch2' | 'ch3' | 'ch4'
     * @param {number} raw  - 4-20mA: mA；RTD: Ω；TC: mV
     */
    setRaw(chId, raw) {
        if (this.sysFault) return;
        const ch = this.channels[chId];
        if (ch !== undefined && ch.mode === 'normal') ch.raw = raw;
    }

    /**
     * 直接设置工程量（仅在 test 模式下生效）
     * 自动反算 raw 值以保持一致
     */
    setValue(chId, value) {
        const ch  = this.channels[chId];
        const rng = this.ranges[chId];
        if (!ch || !rng || ch.mode !== 'test') return;
        ch.value = value;
        ch.fault = false;
        switch (ch.type) {
            case '4-20mA': ch.raw = 4 + ((value - rng.lrv) / (rng.urv - rng.lrv)) * 16;   break;
            case 'RTD':    ch.raw = 100 * (1 + 0.00385 * value);                             break;
            case 'TC':     ch.raw = value * 0.04;                                             break;
        }
    }

    /** 获取所有通道工程量（供中央计算机轮询读取）*/
    getChannelValues() {
        return Object.keys(this.channels).reduce((acc, id) => {
            acc[id] = {
                value: this.channels[id].value,
                fault: this.channels[id].fault,
                alarm: this.alarms[id].status,
                unit:  this.ranges[id].unit,
                mode:  this.channels[id].mode,
            };
            return acc;
        }, {});
    }

    /**
     * 设置通道模式
     * @param {string} chId - 'ch1' | 'ch2' | 'ch3' | 'ch4'
     * @param {string} mode - 'normal' | 'test' | 'disable'
     */
    setChannelMode(chId, mode) {
        const ch = this.channels[chId];
        if (ch !== undefined && ['normal', 'test', 'disable'].includes(mode)) ch.mode = mode;
    }

    /** 销毁模块（定时器已迁移至集中 tick，无需清理） */
    destroy() {
        super.destroy && super.destroy();
    }
}

// ─────────────────────────────────────────────
//  混入图形和 CAN 方法到原型
// ─────────────────────────────────────────────
applyVisualsMixin(AIModule.prototype);
applyCANMixin(AIModule.prototype);