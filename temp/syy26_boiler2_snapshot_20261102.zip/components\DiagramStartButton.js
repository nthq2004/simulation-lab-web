import { BaseComponent } from './BaseComponent.js';

export class DiagramStartButton extends BaseComponent {
    constructor(config, sys) {
        super(config, sys);

        this.width  = Math.max(80, config.width  || 100);
        this.height = Math.max(80, config.height || 100);

        this.type    = 'PUSHBUTTON';
        this.special = 'START-BTN';
        this.cache   = 'fixed';

        this._isPressed = false;
        this._manualPressed = false;
        this._everPressed = false;   // 是否曾被按下（供工作流检测"按钮曾经按下"）
        this._curBladeAng = -22.5;
        this._contactR = 5;

        // 按钮符号颜色（默认绿色启动按钮；可传 color 改为红色等）
        this.poleColor = config.color || '#20a030';

        this._initGroups();
        this._recalcGeometry();
        this._initParameters(config);
        this._init();

        this.config = { id: this.id, label: this.label };

        this.addPort(2, this.height / 2 - 10, 'no1', 'wire');
        this.addPort(this.width - 2, this.height / 2 - 10, 'no2', 'wire', 'p');
    }

    _recalcGeometry() {
        const W = this.width, H = this.height;
        this._cx = W / 2;
        // 左右静触点间距缩至原 2/3（端子位置不变，触点向中心收拢）
        const _gap = (W - 40) * 2 / 3;
        this._leftX = (W - _gap) / 2;
        this._rightX = (W + _gap) / 2;
        this._pivotY = H / 2 - 10;
        this._contactInY = this._pivotY - 20;
    }

    _initParameters(config) {
        this.label = config.label || 'SB';
    }

    _init() {
        this._drawStaticParts();
        this._createDynamicNodes();
        this._bindInteraction();
    }

    _drawStaticParts() {
        const W = this.width, H = this.height;
        const cy = this._pivotY;
        const poleColor = this.poleColor;

        // 左端子 → 左静触头
        this._staticGroup.add(new Konva.Line({
            points: [2, cy, this._leftX, cy],
            stroke: poleColor, strokeWidth: 2,
        }));

        // 右端子 → 右静触头
        this._staticGroup.add(new Konva.Line({
            points: [this._rightX, cy, W - 2, cy],
            stroke: poleColor, strokeWidth: 2,
        }));

        // 左静触头（小圆点）
        this._staticGroup.add(new Konva.Circle({
            x: this._leftX, y: cy, radius: 4,
            fill: poleColor, stroke: '#908030', strokeWidth: 0.8,
        }));

        // 右静触头（小圆点）
        this._staticGroup.add(new Konva.Circle({
            x: this._rightX, y: cy, radius: 4,
            fill: poleColor, stroke: '#908030', strokeWidth: 0.8,
        }));

        // 端子圆点
        this._drawTerminal(2, cy, poleColor);
        this._drawTerminal(W - 2, cy, poleColor);

        // 倒山字按钮帽（底部，靠近开关）
        this._drawButtonCap(this._cx, H - 20, poleColor);

        this._staticGroup.add(new Konva.Text({
            x: 0, y: 18, width: W,
            text: this.label, fontSize: 14, fill: '#333', align: 'center',fontStyle:'bold',
        }));
    }

    _drawButtonCap(cx, y, color) {
        const hatH = 13;
        const sideH = 10;

        // 底部横线
        this._staticGroup.add(new Konva.Line({
            points: [cx - 14, y, cx + 14, y],
            stroke: color, strokeWidth: 2.5,
        }));
        // 左竖线（高）
        this._staticGroup.add(new Konva.Line({
            points: [cx - 14, y, cx - 14, y - sideH],
            stroke: color, strokeWidth: 2,
        }));
        // 中竖线（高）
        this._staticGroup.add(new Konva.Line({
            points: [cx, y, cx, y - hatH],
            stroke: color, strokeWidth: 2,
        }));
        // 右竖线（高）
        this._staticGroup.add(new Konva.Line({
            points: [cx + 14, y, cx + 14, y - sideH],
            stroke: color, strokeWidth: 2,
        }));
    }

    _drawTerminal(x, y, color) {
        this._staticGroup.add(new Konva.Circle({
            x, y, radius: 4,
            fillLinearGradientStartPoint: { x: -4, y: -4 },
            fillLinearGradientEndPoint:   { x: 4, y: 4 },
            fillLinearGradientColorStops: [0, '#d8c870', 0.5, '#f0e090', 1, '#b8a858'],
            stroke: '#908030', strokeWidth: 1,
        }));
    }

    _createDynamicNodes() {
        const cx = this._cx;

        // 推杆虚线（从按钮帽到旋转点）
        this._plungerLine = new Konva.Line({
            points: [cx, this.height - 30, cx, this._pivotY+15 ],
            stroke: this.poleColor, strokeWidth: 1.5,
            dash: [4, 3],
        });
        this._dynamicGroup.add(this._plungerLine);

        // 旋转触点臂（围绕右端子旋转）
        this._bladeGroup = new Konva.Group({
            x: this._rightX,
            y: this._pivotY,
            rotation: this._curBladeAng,
        });

        // 刀片线
        this._bladeGroup.add(new Konva.Line({
            points: [0, 0, -(this._rightX - this._leftX), 0],
            stroke: '#e03030', strokeWidth: 2.5, lineCap: 'round',
        }));

        // 动触点小半圆（面向左侧静触点）
        this._bladeGroup.add(new Konva.Arc({
            x: -(this._rightX - this._leftX), y: 0,
            innerRadius: 0, outerRadius: this._contactR,
            angle: 180, rotation: 180,
            fill: '#e8c86a', stroke: '#e03030', strokeWidth: 1.5,
        }));

        this._dynamicGroup.add(this._bladeGroup);
    }

    _bindInteraction() {
        const hitArea = new Konva.Rect({
            x: this._cx - 20, y: this.height - 35,
            width: 40, height: 30,
            fill: 'transparent',
        });
        hitArea.on('mousedown touchstart', (e) => {
            e.cancelBubble = true;
            this._isPressed = true;
            this._everPressed = true;
            this._curBladeAng = -5;
            this._bladeGroup.rotation(-5);
            this._updatePlunger();
        });
        hitArea.on('mouseup touchend', (e) => {
            e.cancelBubble = true;
            this._isPressed = false;
            this._curBladeAng = -22.5;
            this._bladeGroup.rotation(-22.5);
            this._updatePlunger();
        });
        hitArea.on('mouseenter', () => { document.body.style.cursor = 'pointer'; });
        hitArea.on('mouseleave', () => {
            document.body.style.cursor = 'default';
            if (this._isPressed) {
                this._isPressed = false;
                this._curBladeAng = -22.5;
                this._bladeGroup.rotation(-22.5);
                this._updatePlunger();
            }
        });
        this._interactGroup.add(hitArea);
    }

    _updatePlunger() {
        const cy = this._pivotY;
        const rad = this._curBladeAng * Math.PI / 180;
        const armLen = this._rightX - this._leftX;
        const tipY = cy - armLen * Math.sin(rad);
        this._plungerLine.points([this._cx, this.height - 25, this._cx, tipY-5]);
    }

    getValue() {
        return (this._isPressed || this._manualPressed) ? 0.01 : 10000000;
    }

    /** 模拟闭合/断开（右键菜单用）：等效于按下/松开按钮 */
    setManualOverride(v) {
        this._manualPressed = !!v;
        if (this._manualPressed) this._everPressed = true;
        const ang = this._manualPressed ? -5 : -22.5;
        this._curBladeAng = ang;
        this._bladeGroup.rotation(ang);
        this._updatePlunger();
        this.markDirty();
        this._refreshIfDirty();
    }

    getManualOverride() {
        return !!this._manualPressed;
    }

    showContextMenu(evt) {
        const oldMenu = document.getElementById('comp-context-menu');
        if (oldMenu) oldMenu.remove();

        const menu = document.createElement('div');
        menu.id = 'comp-context-menu';
        menu.style = `position: fixed; top: ${evt.clientY}px; left: ${evt.clientX}px;
            background: white; border: 1px solid #ccc; border-radius: 4px;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.2); z-index: 10000;
            padding: 5px 0; min-width: 120px; font-family: sans-serif; font-size: 14px;`;

        const createItem = (label, onClick) => {
            const item = document.createElement('div');
            item.innerText = label;
            item.style = 'padding: 8px 15px; cursor: pointer; transition: background 0.2s;';
            item.onmouseenter = () => item.style.background = '#f0f0f0';
            item.onmouseleave = () => item.style.background = 'transparent';
            item.onclick = () => { onClick(); menu.remove(); };
            return item;
        };

        menu.appendChild(createItem('向右旋转 90°', () => this.rotate(90)));
        menu.appendChild(createItem('向左旋转 90°', () => this.rotate(-90)));
        menu.appendChild(createItem('参数设置', () => this.showConfigDialog()));

        const isClosed = this.getManualOverride();
        menu.appendChild(createItem(isClosed ? '模拟断开' : '模拟闭合', () => {
            this.setManualOverride(!isClosed);
        }));

        this.sys.container.appendChild(menu);
        const closeMenu = () => { menu.remove(); window.removeEventListener('click', closeMenu); };
        window.addEventListener('click', closeMenu);
    }

    tick(dt) {}

    /** 返回可点击部件中心坐标（供工作流 find/箭头指示定位）：'btn' = 按钮帽中心 */
    getClickablePartCenter(partId) {
        const rel = (partId === 'btn' || !partId)
            ? { x: this._cx, y: this.height - 20 }    // 按钮帽
            : { x: this.width / 2, y: this.height / 2 };
        // 本地坐标 → 画布绝对坐标：计入组件旋转/缩放（右键旋转后仍指得准）
        if (this.group && typeof this.group.getAbsoluteTransform === 'function') {
            const pt = this.group.getAbsoluteTransform().point(rel);
            return { x: pt.x, y: pt.y };
        }
        const gx = this.group ? this.group.x() : 0;
        const gy = this.group ? this.group.y() : 0;
        return { x: gx + rel.x, y: gy + rel.y };
    }

    getConfigFields() {
        return [{ label: '位号', key: 'label', type: 'text' }];
    }

    onConfigUpdate(cfg) {
        if (cfg.label !== undefined) this.label = cfg.label;
        if (cfg.color !== undefined) this.poleColor = cfg.color;
        this.config = { ...this.config, ...cfg };
        this._staticGroup.destroyChildren();
        this._dynamicGroup.destroyChildren();
        this._drawStaticParts();
        this._createDynamicNodes();
        this._refreshCache?.();
    }

    destroy() { super.destroy?.(); }
}
