/**
 * Multimeter.js
 * 基于 Konva.js 的万用表组件（注释版）
 *
 * 说明:
 * - 该组件继承自 `BaseComponent`，在画布上以 Group 的局部坐标绘制一个便携式数字万用表。
 * - 支持常见档位：OFF, 直流电压(多量程), 交流电压, 电阻/通断/二极管档, 毫安档, 电容档等。
 * - 采用 Konva 的静态/动态/交互分组策略（`_staticGroup`、`_dynamicGroup`、`_interactGroup`），并使用 `cache='fixed'` 提高渲染性能。
 * - 逻辑以 `this.mode` 驱动显示与蜂鸣器逻辑；测量值通过 `update(val)` 接收并做节流显示。
 *
 * 单位与映射规则（实现说明）:
 * - 直流电压档: 内部 `this.value` 以伏特 (V) 表示，`DCVmv` 会乘以1000显示为 mV。
 * - 直流电流档: 内部以安培 (A) 表示，显示时根据大小切换 uA/mA/A 单位。
 * - 电阻档: 假设外部提供的值以欧姆 (Ω) 为单位；某些档位会以 kΩ 显示。
 * - 二极管/蜂鸣档: 通过阈值判断正向压降或导通（模拟蜂鸣与显示发光）。
 * - 溢出 (overload): 超出量程时显示 `O.L`。
 *
 * 注意:
 * - 注释仅为文档说明，不修改原有行为。
 */
import { BaseComponent } from './BaseComponent.js';

export class Multimeter extends BaseComponent {
    /**
     * 构造函数
     * @param {object} config - 组件配置（宽高等）
     * @param {object} sys - 系统上下文，包含 stage、请求重绘等方法
     *
     * 构造时：
     * - 初始化绘图分组 `_initGroups()`（在 BaseComponent 中定义）
     * - 设置缩放、尺寸、默认状态与端口（mA, COM, V）
     */
    constructor(config, sys) {
        super(config, sys);

        this.type = 'multimeter';
        this.cache = 'fixed'; // 用于静态缓存的特殊标识

        this._initGroups();
        this._recalcGeometry(config);
        this._initParameters(config);
        this._init();

        this.config = { id: this.id };

        // 底部插孔（物理端口）说明：
        // - 左：`ma`，用于毫安档/电流测量（红）
        // - 中：`com`，公共端（黑）
        // - 右：`v`，用于电压/电阻/二极管等测量（红）
        const spacing = Math.floor(this.width / 3.3333333); // approx 90 for width=300
        const startX = this.width / 2 - spacing;
        this.addPort(startX, this.height - 25, 'ma', 'wire', 'p');
        this.addPort(startX + spacing, this.height - 25, 'com', 'wire');
        this.addPort(startX + 2 * spacing, this.height - 25, 'v', 'wire', 'p');
    }

    // ═══════════════════════════════════════════════════════
    // 几何 / 参数
    // ═══════════════════════════════════════════════════════

    _recalcGeometry(config) {
        this.scale = 1;
        this.width = (config.width || 240) * this.scale;
        this.height = (config.height || 400) * this.scale;
        this._cx = this.width / 2;
        this._knobY = Math.floor(this.height * 0.63);
        this._lcdWidth = Math.min(220 * this.scale, Math.max(200 * this.scale, Math.floor(this.width - 80 * this.scale)));
        this._lcdHeight = 90 * this.scale;
        this._lcdX = Math.floor((this.width - this._lcdWidth) / 2);
        this._lcdY = 40 * this.scale;
    }

    _initParameters(_config) {
        this.mode = 'OFF';       // 当前档位: OFF, DCV, ACV, RES, DIODE, DCMA, ...
        this.value = 1000000;    // 输入的物理值
        this.displayValue = 'O.L';
        this._lastMode = undefined;
        // 更新节流参数（ms）——仅真正更新显示与蜂鸣的频率
        this._displayThrottle = 200;
        this._lastUpdateAt = 0;
        this._pendingValue = null;
        this._pendingTimer = null;
    }

    _init() {
        this._drawStaticParts();
        this._createDynamicNodes();
        this._bindInteraction();
    }

    // ═══════════════════════════════════════════════════════
    // 静态部件
    // ═══════════════════════════════════════════════════════

    _drawStaticParts() {
        // --- 外壳 (青色边框 + 深灰面板) ---
        this._staticGroup.add(new Konva.Rect({
            x: 0, y: 0,
            width: this.width, height: this.height,
            fill: '#444', stroke: '#00ced1', strokeWidth: 12 * this.scale,
            cornerRadius: 40 * this.scale,
        }));

        // --- 挡位文字标注 ---
        this._drawScaleLabels(this._cx, this._knobY);

        // --- 插孔区域 ---
        this._drawJacks(this._cx, Math.floor(this.height - 25));
    }

    // ═══════════════════════════════════════════════════════
    // 动态节点
    // ═══════════════════════════════════════════════════════

    _createDynamicNodes() {
        const lcdWidth = this._lcdWidth, lcdHeight = this._lcdHeight;
        const lcdX = this._lcdX, lcdY = this._lcdY;

        this.lcdBg = new Konva.Rect({
            x: lcdX, y: lcdY, width: lcdWidth, height: lcdHeight,
            fill: '#c5ccb7', stroke: '#222', strokeWidth: 2 * this.scale, cornerRadius: 5 * this.scale,
        });
        this.lcdText = new Konva.Text({
            x: lcdX + 10 * this.scale, y: lcdY + 15 * this.scale,
            text: ' ', fontSize: Math.min(60 * this.scale, Math.floor(this.width / 6)), fontFamily: 'monospace',
            fill: '#222', width: lcdWidth - 20 * this.scale, align: 'right', fontStyle: 'bold',
        });
        this.lcdUnit = new Konva.Text({
            x: lcdX + lcdWidth - 30 * this.scale, y: lcdY + lcdHeight - 30 * this.scale,
            text: ' ', fontSize: 20 * this.scale, fill: '#222',
        });
        this.lcdMode = new Konva.Text({
            x: lcdX + 10 * this.scale, y: lcdY + lcdHeight - 25 * this.scale,
            text: ' ', fontSize: 14 * this.scale, fill: '#e3142f',
        });
        this._dynamicGroup.add(this.lcdBg, this.lcdText, this.lcdUnit, this.lcdMode);

        // --- 挡位旋钮（交互）---
        const knobRadius = Math.min(80 * this.scale, Math.floor(this.width * 0.26));
        this.knobGroup = new Konva.Group({ x: this._cx, y: this._knobY });
        const knobCircle = new Konva.Circle({ radius: knobRadius, fill: '#333', stroke: '#111', strokeWidth: 5 * this.scale });

        const resArc = new Konva.Arc({ InnerRadius: knobRadius - 3 * this.scale, outerRadius: knobRadius, angle: 90, rotation: -60, fill: '#17e760', stroke: '#08df2f', strokeWidth: 1 * this.scale });
        const acArc = new Konva.Arc({ InnerRadius: knobRadius - 3 * this.scale, outerRadius: knobRadius, angle: 30, rotation: 120, fill: '#f17c08', stroke: '#ec9819', strokeWidth: 1 * this.scale });
        const dcArc = new Konva.Arc({ InnerRadius: knobRadius - 3 * this.scale, outerRadius: knobRadius, angle: 60, rotation: 180, fill: '#f10808', stroke: '#f00505', strokeWidth: 1 * this.scale });
        this.pointer = new Konva.Line({
            points: [0, -10 * this.scale, 0, -Math.floor(knobRadius * 0.9)],
            stroke: '#999', strokeWidth: Math.max(10 * this.scale, Math.floor(knobRadius * 0.1)), lineCap: 'round',
        });
        this.knobGroup.add(knobCircle, this.pointer, resArc, acArc, dcArc);
        this.pointer.rotation(0);
        this._interactGroup.add(this.knobGroup);
    }

    // ═══════════════════════════════════════════════════════
    // 交互
    // ═══════════════════════════════════════════════════════

    _bindInteraction() {
        // 鼠标按下或触摸开始时旋转切换量程
        this.knobGroup.on('mousedown touchstart', (e) => {
            e.cancelBubble = true;
            this._rotateKnob(e);
            if (this.sys.onComponentStateChange) this.sys.onComponentStateChange(this);
        });
        // 阻止旋钮上的双击事件冒泡到 group，防止弹出配置框
        this.knobGroup.on('dblclick', (e) => {
            e.cancelBubble = true;
        });
    }

    /**
     * 绘制旋钮周围的刻度文字与刻度点
     * 参数 `scales` 定义了每个刻度对应的文本与角度（用于 `_updateModeByAngle`/`_updateAngleByMode` 的映射）
     */
    _drawScaleLabels(cx, cy) {
        const scales = [
            { label: 'OFF', angle: 0, mode: 'OFF' },
            { label: '200mv', angle: -30, mode: 'DCVmv' },
            { label: '20V', angle: -60, mode: 'DCV20' },
            { label: '200V', angle: -90, mode: 'DCV200' },
            { label: '~200V', angle: -120, mode: 'ACV200' },
            { label: '~500V', angle: -150, mode: 'ACV500' },
            { label: '▶|-))', angle: 30, mode: 'DIODE' },
            { label: '200Ω', angle: 60, mode: 'RES200' },
            { label: '2kΩ', angle: 90, mode: 'RES2k' },
            { label: '200kΩ', angle: 120, mode: 'RES200k' },
            { label: 'mA', angle: 150, mode: 'MA' },
            { label: 'uF', angle: 180, mode: 'C' }
        ];

        const radius = Math.min(110 * this.scale, Math.max(40 * this.scale, Math.floor(this.width / 3)));
        const knobRadius = Math.min(80 * this.scale, Math.floor(this.width * 0.26));
        scales.forEach(s => {
            const rad = (s.angle - 90) * (Math.PI / 180);
            const x = cx + Math.cos(rad) * radius;
            const y = cy + Math.sin(rad) * radius;
            const markx = cx + Math.cos(rad) * knobRadius;
            const marky = cy + Math.sin(rad) * knobRadius;
            const mark = new Konva.Circle({
                x: markx, y: marky, radius: 3 * this.scale, fill: '#0e5ae7', stroke: '#1165eb', strokeWidth: 1 * this.scale,
            });

            const text = new Konva.Text({
                x: x - 20 * this.scale, y: y - 6 * this.scale,
                text: s.label, fontSize: 12 * this.scale, fill: '#fff', width: 40 * this.scale, align: 'center'
            });
            this._staticGroup.add(text, mark);
        });
    }

    /**
     * 绘制底部插孔视觉与文字标签
     * 仅作视觉效果，实际电气逻辑由系统端口连接处理。
     */
    _drawJacks(cx, y) {
        const jackLabels = ['mA', 'COM', 'VΩ▶|'];
        const colors = ['#c00', '#000', '#c00'];

        const spacing = Math.floor(this.width / 3.3333333); // approx 90 for width=300
        const startX = cx - spacing;
        const jackRadius = Math.max(8 * this.scale, Math.min(20 * this.scale, Math.floor(this.width * 0.06)));

        jackLabels.forEach((l, i) => {
            const x = startX + i * spacing;
            const jack = new Konva.Circle({
                x: x, y: y, radius: jackRadius, fill: colors[i], stroke: '#111', strokeWidth: 3 * this.scale
            });
            const inner = new Konva.Circle({
                x: x, y: y, radius: Math.floor(jackRadius * 0.6), fill: '#222', stroke: '#333', strokeWidth: 3 * this.scale
            });
            const label = new Konva.Text({
                x: x - Math.floor(jackRadius * 3), y: y - (jackRadius + 20 * this.scale), text: l, fontSize: 12 * this.scale, fill: '#fff', width: Math.floor(jackRadius * 6), align: 'center'
            });
            this._staticGroup.add(jack, inner, label);

        });
    }

    /**
     * 逻辑：旋转旋钮并切换模式
     */
    /**
     * 旋转旋钮并切换 `this.mode`
     * - 以点击位置决定方向，每次步进 30°。
     * - rotation 经过归一化后交由 `_updateModeByAngle` 映射到具体量程字符串。
     */
    _rotateKnob(e) {
        // 点击决定旋转方向：点击在指针顺时针方向 -> 顺时针转动；点击在逆时针方向 -> 逆时针转动
        // 步进 30°，限制在 [-90, 90]
        const stage = this.sys.stage;
        if (!stage) return;
        const pointerPos = stage.getPointerPosition();
        if (!pointerPos) return;

        const knobAbs = this.knobGroup.getAbsolutePosition();
        const dx = pointerPos.x - knobAbs.x;
        const dy = pointerPos.y - knobAbs.y;

        const clickAngle = Math.atan2(dy, dx) * 180 / Math.PI; // 相对于 +x 轴
        const desiredRotation = clickAngle + 90; // 将 +x 轴角度转换为 rotation 空间（rotation=0 指向上）

        const currentRotation = this.pointer.rotation();

        let delta = desiredRotation - currentRotation;
        // 归一化到 (-180,180]
        delta = ((delta + 540) % 360) - 180;

        const step = 30;
        const minRot = -3600;
        const maxRot = 3600;

        let newRotation = currentRotation;
        if (delta > 1) {
            newRotation = Math.min(maxRot, currentRotation + step);
        } else if (delta < -1) {
            newRotation = Math.max(minRot, currentRotation - step);
        } else {
            return; // 点击在指针方向附近，不变
        }

        if (Math.abs(newRotation - currentRotation) < 1e-6) return;

        this.pointer.rotation(newRotation);
        this._updateModeByAngle(newRotation);

        this._measureNow();
    }

    /**
     * 切档后立即用当前档位真实测量值刷新显示。
     * 不沿用上一档位的旧读数（例如 RES 档 O.L 哨兵 1000000），
     * 否则切到 ACV 档会错误地显示 O.L（直到下一帧 tick 才被真实电压覆盖）。
     */
    _measureNow() {
        // 绕过节流：清除 pending 并强制下一次 update 立即渲染，
        // 避免切档后仍沿用上一档位屏幕上的旧读数（如 RES 档 O.L）
        if (this._pendingTimer) {
            clearTimeout(this._pendingTimer);
            this._pendingTimer = null;
        }
        this._pendingValue = null;
        this._lastUpdateAt = 0;
        if (this.mode === 'OFF') {
            this.update(0);
            return;
        }
        const s = this.sys?.voltageSolver;
        if (s) this.tick(0);
    }

    /**
     * 根据旋转角度映射到档位标识（`this.mode`）
     * 角度映射规则与 `_drawScaleLabels` 中 `scales` 保持一致。
     */
    _updateModeByAngle(angle) {
        // 归一化角度到 0-360 之间
        const normalizedAngle = (angle % 360 + 360) % 360;

        /**
            { label: 'OFF', angle: 0, mode: 'OFF' },
            { label: '200mv', angle: -30, mode: 'DCVmv' },
            { label: '20V', angle: -60, mode: 'DCV20' },
            { label: '200V', angle: -90, mode: 'DCV200' },
            { label: '~200V', angle: -120, mode: 'ACV200' },
            { label: '~500V', angle: -150, mode: 'ACV500' },
            { label: '▶|', angle: 30, mode: 'DIODE' },
            { label: '200Ω', angle: 60, mode: 'RES200' },
            { label: '2kΩ', angle: 90, mode: 'RES2k' },
            { label: '200kΩ', angle: 120, mode: 'RES200k' },
            { label: 'mA', angle: 150, mode: 'MA' },
            { label: 'uF', angle: 180, mode: 'C' }
         */

        switch (true) {

            case (normalizedAngle >= 350 || normalizedAngle < 10):
                this.mode = 'OFF';
                break;
            case (normalizedAngle >= 20 && normalizedAngle < 40):
                this.mode = 'DIODE';
                break;
            case (normalizedAngle >= 50 && normalizedAngle < 70):
                this.mode = 'RES200';
                break;
            case (normalizedAngle >= 80 && normalizedAngle < 100):
                this.mode = 'RES2k';
                break;
            case (normalizedAngle >= 110 && normalizedAngle < 130):
                this.mode = 'RES200k';
                break;
            case (normalizedAngle >= 140 && normalizedAngle < 160):
                this.mode = 'MA';
                break;
            case (normalizedAngle >= 170 && normalizedAngle < 190):
                this.mode = 'C';
                break;
            case (normalizedAngle >= 200 && normalizedAngle < 220):
                this.mode = 'ACV500';
                break;
            case (normalizedAngle >= 230 && normalizedAngle < 250):
                this.mode = 'ACV200';
                break;
            case (normalizedAngle >= 260 && normalizedAngle < 280):
                this.mode = 'DCV200';
                break;
            case (normalizedAngle >= 290 && normalizedAngle < 310):
                this.mode = 'DCV20';
                break;
            case (normalizedAngle >= 320 && normalizedAngle < 340):
                this.mode = 'DCVmv';
                break;
            default:
                this.mode = 'OFF';
        }

        // 档位变化时重置测量缓冲：避免 ACV/电流档的 RMS 环形缓冲残留旧档位数据，
        // 导致切档后移动表笔仍显示上一点的大电压（如断点电压残留为 O.L/大数）
        if (this.mode !== this._lastMode) {
            this._resetMeasureBuffers();
        }
    }

    /**
     * 档位变化时重置 RMS 环形缓冲（ACV 电压 / mA 电流）
     */
    _resetMeasureBuffers() {
        this._lastMode = this.mode;
        if (this.mode.startsWith('ACV')) {
            this._acvBuf = null;
            this._acvSumSq = 0;
            this._acvIdx = 0;
            this._acvCount = 0;
        }
        if (this.mode === 'MA') {
            this._acCBuf = null;
            this._acCSumSq = 0;
            this._acCIdx = 0;
            this._acCCount = 0;
        }
        // 电容档测量状态复位（切换档位后重新充电测量）
        this._capKey = null;
        this._capDone = false;
        this._capTimer = 0;
        this._capSimTime = 0;
        this._capV0 = undefined;
        this._capIter = undefined;
        this._capValue = null;
    }
    /**
     * 根据当前 `this.mode` 设置旋钮指针角度（用于程序改变档位时同步 UI）
     */
    _updateAngleByMode() {
        /**
    { label: 'OFF', angle: 0, mode: 'OFF' },
    { label: '200mv', angle: -30, mode: 'DCVmv' },
    { label: '20V', angle: -60, mode: 'DCV20' },
    { label: '200V', angle: -90, mode: 'DCV200' },
    { label: '~200V', angle: -120, mode: 'ACV200' },
    { label: '~500V', angle: -150, mode: 'ACV500' },
    { label: '▶|', angle: 30, mode: 'DIODE' },
    { label: '200Ω', angle: 60, mode: 'RES200' },
    { label: '2kΩ', angle: 90, mode: 'RES2k' },
    { label: '200kΩ', angle: 120, mode: 'RES200k' },
    { label: 'mA', angle: 150, mode: 'MA' },
    { label: 'uF', angle: 180, mode: 'C' }
 */
        switch (this.mode) {
            case 'DCVmv':
                this.pointer.rotation(-30);
                break;
            case 'DCV20':
                this.pointer.rotation(-60);
                break;
            case 'DCV200':
                this.pointer.rotation(-90);
                break;
            case 'ACV200':
                this.pointer.rotation(-120);
                break;
            case 'ACV500':
                this.pointer.rotation(-150);
                break;
            case 'OFF':
                this.pointer.rotation(0);
                break;
            // --- 电阻与通断档 ---
            case 'DIODE': // 蜂鸣/二极管档
                this.pointer.rotation(30);
                break;
            case 'RES200':
                this.pointer.rotation(60);
                break;
            case 'RES2k':
                this.pointer.rotation(90);
                break;
            case 'RES200k':
                this.pointer.rotation(120);
                break;

            // --- 电流与电容档 ---
            case 'MA':
                this.pointer.rotation(150);
                break;
            case 'C':
                this.pointer.rotation(180);
                break;

            default:
                break;
        }
        if (this.mode !== this._lastMode) {
            this._resetMeasureBuffers();
        }
        this._measureNow();
    }
    /**
 * 停止蜂鸣器声音
 * 采用安全的状态检查，确保振荡器被彻底销毁
 */
    // MultiMeter 类内部方法：播放/停止蜂鸣并安全清理音频节点与定时器
    /**
     * 控制蜂鸣器（短促音）并安全清理 AudioNode
     * - 使用 Web Audio API 创建方波振荡器并在短时后释放资源
     * - 多次触发会先清理已有振荡器以避免资源泄露
     */
    triggerBeep(isBeeping) {
        if (!this.lcdText) return;

        if (isBeeping) {
            // 本次测量已响过 3 声则不再响，避免持续鸣叫
            if (this._beepFired) return;
            this._beepFired = true;
            this.isBeepingNow = true;
            this._beepSequence = 0;
            this._playBeepTone();
        } else {
            // 立即停止蜂鸣并清理，复位计数，等待下一次导通重新响 3 声
            this._stopBeepTone();
            this._beepFired = false;
            try { this.lcdText.fill('#222'); } catch (e) { }
        }
    }

    /** 播放一声短促蜂鸣（130ms），间隔 220ms 播下一声，共 3 声 */
    _playBeepTone() {
        if (this._beepSequence >= 3) {
            this.isBeepingNow = false;
            this._beepSequence = 0;
            // 恢复为默认颜色（update 可能再次设置颜色）
            try { this.lcdText.fill('#222'); } catch (e) { }
            return;
        }

        if (!this.audioCtx) this.audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        if (this.audioCtx.state === 'suspended') {
            this.audioCtx.resume().catch(() => { });
        }

        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(2500, this.audioCtx.currentTime);
        gain.gain.setValueAtTime(0.12, this.audioCtx.currentTime);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        try { osc.start(); } catch (e) { }
        this._osc = osc;
        this._gain = gain;

        // 本声结束后释放资源
        setTimeout(() => {
            if (this._osc === osc) this._osc = null;
            if (this._gain === gain) this._gain = null;
            try { osc.stop(); } catch (e) { }
            try { osc.disconnect(); } catch (e) { }
            try { gain.disconnect(); } catch (e) { }
        }, 130);

        this._beepSequence++;
        this._beepTimer = setTimeout(() => this._playBeepTone(), 220);
    }

    /** 立即停止蜂鸣序列并清理音频资源 */
    _stopBeepTone() {
        if (this._beepTimer) {
            clearTimeout(this._beepTimer);
            this._beepTimer = null;
        }
        if (this._osc) {
            try { this._osc.stop(); } catch (e) { }
            try { this._osc.disconnect(); } catch (e) { }
            this._osc = null;
        }
        if (this._gain) {
            try { this._gain.disconnect(); } catch (e) { }
            this._gain = null;
        }
        this.isBeepingNow = false;
        this._beepSequence = 0;
    }

    /**
     * 接收来自外部的测量值并更新显示（节流处理）
     * @param {number} val - 外部传入的物理量（内部约定：电压以 V，电流以 A，电阻以 Ω）
     *
     * 显示与量程规则：
     * - 根据 `this.mode` 决定单位、精度与是否溢出（`O.L`）。
     * - 为减轻主线程压力，采用 `_displayThrottle` 合并快速到来的多次更新。
     */
    update(val) {
        if (val == null || isNaN(val)) val = 1000000;
        this.value = val;

        const now = performance.now();
        const elapsed = now - (this._lastUpdateAt || 0);
        // 若离上次实际屏幕更新未满节流间隔，则延迟合并更新
        if (elapsed < this._displayThrottle) {
            this._pendingValue = val;
            if (!this._pendingTimer) {
                const wait = Math.max(1, this._displayThrottle - elapsed);
                this._pendingTimer = setTimeout(() => {
                    this._pendingTimer = null;
                    // 强制立即应用 pending 值（若已被正常路径消费则跳过）
                    if (this._pendingValue == null) return;
                    try { this.update(this._pendingValue); } catch (e) { }
                }, wait);
            }
            return; // 跳过实际 DOM/Konva 更新以减轻主线程负担
        }
        // 记录本次实际更新时间
        this._lastUpdateAt = now;
        // 清除未触发的 pending timer，避免其回调读取已重置的 _pendingValue 造成 update(null)
        if (this._pendingTimer) {
            clearTimeout(this._pendingTimer);
            this._pendingTimer = null;
        }
        this._pendingValue = null;

        // 1. 关机状态处理：OFF 档清空显示并关闭蜂鸣器
        if (this.mode === 'OFF') {
            this.lcdText.text('');
            this.lcdMode.text('');
            this.lcdUnit.text('');
            this.triggerBeep(false); // 关机必须关声音
            return;
        }

        let display = this.value;
        let unit = '';
        let prefix = 'DC';
        let precision = 3;
        let isOverload = false;

        // 2. 根据 12 种模式处理量程、单位、精度与过载判定
        switch (this.mode) {
            // --- 直流电压档 ---
            // 直流毫伏档：内部值以 V 表示，显示时乘以 1000 => mV
            case 'DCVmv':
                unit = 'mV';
                prefix = 'DC';
                precision = 1;
                display = display * 1000;
                if (Math.abs(display) > 200) isOverload = true;
                break;
            case 'DCV20':
                unit = 'V';
                prefix = 'DC';
                precision = 2; // 19.99V
                if (Math.abs(display) > 20) isOverload = true;
                break;
            case 'DCV200':
                unit = 'V';
                prefix = 'DC';
                precision = 1; // 199.9V
                if (Math.abs(display) > 200) isOverload = true;
                break;

            // --- 交流电压档 ---
            case 'ACV200':
                unit = 'V';
                prefix = 'AC';
                precision = 1;
                if (Math.abs(display) > 200) isOverload = true;
                break;
            case 'ACV500':
                unit = 'V';
                prefix = 'AC';
                precision = 0; // 高压档通常不留小数
                if (Math.abs(display) > 500) isOverload = true;
                break;

            // --- 二极管/通断档（1mA 恒流注入，见 stampMultimeters）---
            //  <0.3V：电压很小 → 按导通电阻显示（R = V/1mA = 1000·V），<5Ω 蜂鸣
            //  0.3~3V：显示管压降
            //  >3V ：视为反向/开路 → O.L
            case 'DIODE':
                this.lcdText.fill('#222');
                if (display < 0.3) {
                    display = display * 1000;
                    unit = 'Ω';
                    prefix = '';
                    precision = 2;
                    if (display < 5) {
                        this.triggerBeep(true);
                    } else {
                        this.triggerBeep(false);
                    }
                    if (display > 200) isOverload = true;
                } else {
                    this.triggerBeep(false);
                    unit = 'V';
                    prefix = '▶|·))';
                    precision = 3;
                    if (display > 3) isOverload = true;
                }
                break;
            case 'RES200':
                unit = 'Ω';
                prefix = '';
                precision = 2;
                if (display > 200) isOverload = true;
                break;
            case 'RES2k':
                unit = 'kΩ';
                prefix = '';
                display = display / 1000;
                precision = 3; // 1.999 kΩ
                if (display > 2) isOverload = true;
                break;
            case 'RES200k':
                unit = 'kΩ';
                prefix = '';
                display = display / 1000;
                precision = 1; // 199.9 kΩ
                if (display > 200) isOverload = true;
                break;

            // --- 电流与电容档 ---
            case 'MA':
                // 电流档：根据数值自动选择 uA/mA/A 单位显示（内部以 A 为基准）
                if (Math.abs(display) < 0.1) {
                    unit = 'uA';
                    display = display * 1000; // A -> mA (此处逻辑为示意，保持原实现)
                }
                else if (Math.abs(display) > 100) {
                    unit = 'A';
                    display = display / 1000;
                } else {
                    unit = 'mA';
                    display = display;
                }
                prefix = 'DC';
                precision = 2;
                if (display > 100) isOverload = true;
                break;
            case 'C':
                unit = 'uF';
                prefix = 'CAP';
                precision = 2;
                if (display > 200) isOverload = true; // 假设最大 200uF
                break;

            default:
                break;

        }

        // 3. 渲染显示内容：超出量程显示 O.L，否则格式化为固定小数位
        if (isOverload) {
            this.lcdText.text('O.L'); // 工业标准溢出显示
        } else {
            this.lcdText.text(display.toFixed(precision));
        }

        this.lcdUnit.text(unit);
        this.lcdMode.text(prefix);

    }


    /** v/com 表笔是否悬空（未接入电路）：所在簇只有该端口自己即视为悬空 */
    _probesFloating(s) {
        if (!s || !s.portToCluster) return false;
        const count = new Map();
        for (const c of s.portToCluster.values()) count.set(c, (count.get(c) || 0) + 1);
        const wired = (pid) => {
            const c = s.portToCluster.get(pid);
            return c !== undefined && (count.get(c) || 0) >= 2;
        };
        return !wired(`${this.id}_wire_v`) || !wired(`${this.id}_wire_com`);
    }

    tick(dt) {
        const s = this.sys?.voltageSolver;
        if (!s) return;
        const mode = this.mode || 'OFF';
        if (mode === 'OFF') return;
        if (mode.startsWith('DCV')) {
            this.update(s.getPD(`${this.id}_wire_v`, `${this.id}_wire_com`) || 0);
        } else if (mode === 'MA') {
            this._updateMACurrent(s);
        } else if (mode.startsWith('RES')) {
            // 表笔悬空 → 显示 O.L（超量程），而不是 0
            if (this._probesFloating(s)) this.update(1000000);
            else this._updateRES(s);
        } else if (mode === 'DIODE') {
            // 表笔悬空 → 显示 O.L
            if (this._probesFloating(s)) this.update(1000000);
            else this._updateDiode(s);
        } else if (mode === 'C') {
            this._updateCapacitance(s, dt);
        } else if (mode.startsWith('ACV')) {
            this._updateACV(s);
        }
    }

    _updateDiode(s) {
        const vPort = Math.abs(s.getPD(`${this.id}_wire_v`, `${this.id}_wire_com`) || 0);
        this.update(vPort);
    }

    /**
     * 电容档测量：恒流充电法
     * 以 1mA 恒流对被测电容充电 3s，读取电容两端电压增量 ΔV，
     * 由 C = I·t / ΔV 计算电容量（t 取求解器实际积分的仿真时间，
     * 避免平台"隔帧跳步"导致的时间偏差）。
     * 充电结束后停止注入电流并保持读数；更换表笔/档位后重新测量。
     */
    _updateCapacitance(s, dt) {
        const CAP_CURRENT = 0.001;   // 1mA 恒流
        const CAP_TIME = 3.0;        // 充电 3s

        const cV = s.portToCluster.get(`${this.id}_wire_v`);
        const cCOM = s.portToCluster.get(`${this.id}_wire_com`);
        if (cV === undefined || cCOM === undefined) {
            this._capKey = null;
            this._capDone = false;
            this.update(1000000);    // 未接线 → O.L
            return;
        }

        const key = `${cV}|${cCOM}`;
        const v = s.getPD(`${this.id}_wire_v`, `${this.id}_wire_com`) || 0;

        // 表笔接入点变化 → 重新开始一次测量
        if (this._capKey !== key) {
            this._capKey = key;
            this._capDone = false;
            this._capTimer = 0;
            this._capSimTime = 0;
            this._capV0 = v;
            this._capIter = s.globalIterCount;
            this._capValue = null;
        }

        if (this._capDone) {
            if (this._capValue != null) this.update(this._capValue);
            return;
        }

        // 累计求解器真正推进的仿真时间（仅在 globalIterCount 变化时累加）
        if (this._capIter === undefined) this._capIter = s.globalIterCount;
        if (s.globalIterCount !== this._capIter) {
            this._capSimTime += s.deltaTime * (s.globalIterCount - this._capIter);
            this._capIter = s.globalIterCount;
        }

        this._capTimer += dt;
        if (this._capTimer < CAP_TIME) return;   // 充电中，暂不刷新读数

        const dV = Math.abs(v - this._capV0);
        if (this._capSimTime <= 0 || dV < 1e-9) {
            this._capValue = 1000000;            // 电压不上升：短路或超出量程
        } else {
            const cUF = CAP_CURRENT * this._capSimTime / dV * 1e6;
            this._capValue = (!isFinite(cUF) || cUF > 1e6) ? 1000000 : cUF;
        }
        this._capDone = true;                    // 停止充电，保持读数
        this.update(this._capValue);
    }

    _updateACV(s) {
        const vDiff = s.getPD(`${this.id}_wire_v`, `${this.id}_wire_com`);
        if (!this._acvBuf) {
            this._acvBuf = new Float64Array(40);
            this._acvSumSq = 0;
            this._acvIdx = 0;
            this._acvCount = 0;
        }
        const buf = this._acvBuf;
        const idx = this._acvIdx;
        this._acvSumSq -= buf[idx];
        // 求解器异常时 vDiff 可能为 NaN/Infinity，按 0 处理避免污染 RMS 缓冲导致永久 O.L
        const sq = Number.isFinite(vDiff) ? vDiff * vDiff : 0;
        buf[idx] = sq;
        this._acvSumSq += sq;
        this._acvIdx = (idx + 1) % buf.length;
        if (this._acvCount < buf.length) this._acvCount++;
        // 浮点误差可能使 _acvSumSq 累积为微小负数，sqrt(负数)=NaN → update(NaN)→O.L
        const rms = this._acvCount > 0 ? Math.sqrt(Math.max(0, this._acvSumSq) / this._acvCount) : 0;
        this._displayRMS = rms < 0.01 ? 0 : rms;
        this.update(this._displayRMS);
    }

    _updateMACurrent(s) {
        const current = this.physCurrent || 0;
        if (!this._acCBuf) {
            this._acCBuf = new Float64Array(40);
            this._acCSumSq = 0;
            this._acCIdx = 0;
            this._acCCount = 0;
        }
        const buf = this._acCBuf;
        const idx = this._acCIdx;
        this._acCSumSq -= buf[idx];
        const sq = Number.isFinite(current) ? current * current : 0;
        buf[idx] = sq;
        this._acCSumSq += sq;
        this._acCIdx = (idx + 1) % buf.length;
        if (this._acCCount < buf.length) this._acCCount++;
        const rms = this._acCCount > 0 ? Math.sqrt(Math.max(0, this._acCSumSq) / this._acCCount) : 0;
        this.update(rms * 1000);
    }

    _updateRES(s) {
        // 恒流源注入测量：R = 端口电压 / 档位测试电流
        const vPort = Math.abs(s.getPD(`${this.id}_wire_v`, `${this.id}_wire_com`) || 0);
        let iSet = 0.001;                                   // RES200：1mA
        if (this.mode === 'RES2k') iSet = 0.0001;            // 2kΩ：0.1mA
        else if (this.mode === 'RES200k') iSet = 0.000001;   // 200kΩ：1µA
        const R = vPort / iSet;
        if (!isFinite(R) || R >= 1e9) {
            this.update(1000000);
        } else {
            this.update(R);
        }
    }

    /**
     * 按档位标识设置旋钮档位（供工作流自动演示切档用）。
     * 角度与 _drawScaleLabels 的 scales 一致：OFF=0，DCVmv=-30，DCV20=-60，DCV200=-90，
     * ACV200=-120，ACV500=-150，DIODE=30，RES200=60，RES2k=90，RES200k=120，MA=150，C=180。
     * @param {string} mode 档位标识
     */
    setMode(mode) {
        const angleMap = {
            'OFF': 0, 'DCVmv': -30, 'DCV20': -60, 'DCV200': -90,
            'ACV200': -120, 'ACV500': -150, 'DIODE': 30, 'RES200': 60,
            'RES2k': 90, 'RES200k': 120, 'MA': 150, 'C': 180,
        };
        const angle = angleMap[mode];
        if (angle === undefined || !this.pointer) return;
        this.pointer.rotation(angle);
        this._updateModeByAngle(angle);
        this._measureNow();
        // 动态内容（LCD/指针）在 _interactGroup，不重建静态缓存，仅请求重绘
        if (this.sys && typeof this.sys.requestRedraw === 'function') this.sys.requestRedraw();
    }

    /* 返回部件中心的世界坐标（供工作流箭头定位） */
    getClickablePartCenter(partId) {
        const gx = this.group.x(), gy = this.group.y();
        const lx = this.width / 2, ly = this.height * 0.63;
        const py = this.height - 25;
        switch (partId) {
            case 'lcd':  return { x: gx + lx, y: gy + 85 };
            case 'knob': return { x: gx + lx, y: gy + ly };
            case 'v':    return { x: gx + this.width * 0.833, y: gy + py };
            case 'com':  return { x: gx + this.width * 0.5,   y: gy + py };
            case 'ma':   return { x: gx + this.width * 0.167, y: gy + py };
            default:     return null;
        }
    }

    destroy() {
        super.destroy?.();
    }
}
