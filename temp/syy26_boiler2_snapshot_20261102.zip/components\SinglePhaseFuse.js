import { BaseComponent } from './BaseComponent.js';

export class SinglePhaseFuse extends BaseComponent {
    constructor(config, sys) {
        super(config, sys);

        this.width  = Math.max(20, config.width  || 28);
        this.height = Math.max(60, config.height || 80);

        this.type    = '1p-fuse';
        this.special = 'fuse';
        this.cache   = 'fixed';

        this._poleCount = 1;

        this._initGroups();
        this._recalcGeometry();
        this._initParameters(config);
        this._init();

        this.config = {
            id: this.id,
            label:        this.label,
            ratedVoltage: this.ratedVoltage,
            ratedCurrent: this.ratedCurrent,
            fuseType:     this.fuseType,
            initState:    this._states[0],
        };

        this.addPort(this._portL.x, this._portL.y, 'l', 'wire', 'p');
        this.addPort(this._portT.x, this._portT.y, 't', 'wire');
    }

    _recalcGeometry() {
        const W = this.width, H = this.height;

        this._cx    = W * 0.50;
        this._inY   = H * 0.18;
        this._outY  = H * 0.82;
        this._boxCY = (this._inY + this._outY) / 2;
        this._boxW  = Math.max(12, W * 0.64);
        this._boxH  = H * 0.48;
        this._boxTop  = this._boxCY - this._boxH / 2;
        this._boxBot  = this._boxCY + this._boxH / 2;
        this._termR   = Math.max(3, W * 0.036);

        this._portL = { x: this._cx, y: 2 };
        this._portT = { x: this._cx, y: H - 2 };
    }

    _initParameters(config) {
        this.ratedVoltage = config.ratedVoltage !== undefined ? config.ratedVoltage : 220;
        this.ratedCurrent = config.ratedCurrent !== undefined ? config.ratedCurrent : 16;
        this.label        = config.label    || 'FU';
        this.fuseType     = config.fuseType || 'RT18-16';

        const s = (config.initState || 'ok').toLowerCase();
        this._states = [s === 'blown' ? 'blown' : 'ok'];

        this._blowAnim   = [0];
        this._blowFrames = 8;
        this._arcFrames  = [0];
        this.opsCount    = config.initOps || 0;
        this._overCurrentFrames = 0;
    }

    _init() {
        this._drawStaticParts();
        this._createDynamicNodes();
        this._bindInteraction();
    }

    _drawStaticParts() {
        this._drawSchematicStatic();
    }

    _drawSchematicStatic() {
        const px = this._cx;
        const poleColor = '#c06820';
        const fs = Math.max(10, this.width * 0.036);

        // 引线：端口 → 接线柱 → IEC 方框
        this._staticGroup.add(new Konva.Line({
            points: [px, 2, px, this._boxTop],
            stroke: poleColor, strokeWidth: 2,
        }));
        this._staticGroup.add(new Konva.Line({
            points: [px, this._boxBot, px, this.height - 2],
            stroke: poleColor, strokeWidth: 2,
        }));

        this._drawTerminalPost({ x: px, y: this._inY }, poleColor);

        this._drawTerminalPost({ x: px, y: this._outY }, poleColor);

        this._staticGroup.add(new Konva.Rect({
            x: px - this._boxW / 2, y: this._boxTop,
            width: this._boxW, height: this._boxH,
            fill: 'rgba(245,240,225,0.85)',
            stroke: poleColor, strokeWidth: 1.5, cornerRadius: 2,
        }));
    }

    _drawTerminalPost(pos, color) {
        const R = this._termR, { x, y } = pos;
        this._staticGroup.add(new Konva.Circle({
            x, y, radius: R,
            fillLinearGradientStartPoint: { x: -R, y: -R },
            fillLinearGradientEndPoint:   { x:  R, y:  R },
            fillLinearGradientColorStops: [0, '#7a6a30', 0.4, '#d4aa52', 0.7, '#e8c86a', 1, '#8a7030'],
            stroke: '#6a5a28', strokeWidth: 1,
        }));
        this._staticGroup.add(new Konva.Circle({
            x, y, radius: R * 0.38, fill: '#2a1a08', stroke: '#5a4a20', strokeWidth: 0.6,
        }));
    }

    _createDynamicNodes() {
        this._createSchematicFuseWires();
        this._arcGroup = new Konva.Group({ listening: false });
        this._dynamicGroup.add(this._arcGroup);
    }

    _createSchematicFuseWires() {
        const px   = this._cx;
        const state = this._states[0];
        const poleColor = '#c06820';
        const boxTop  = this._boxTop, boxBot = this._boxBot;
        const boxMidY = (boxTop + boxBot) / 2;
        const bW = this._boxW;

        const wireGroup = new Konva.Group({ visible: state === 'ok', listening: false });
        wireGroup.add(new Konva.Line({
            points: [px, boxTop + 3, px, boxMidY - bW * 0.45],
            stroke: poleColor, strokeWidth: 2, lineCap: 'round',
        }));
        const wavePts = [];
        for (let s = 0; s <= 6; s++) {
            const t = s / 6;
            wavePts.push(
                px + Math.sin(t * Math.PI * 2) * bW * 0.20,
                (boxMidY - bW * 0.45) + t * bW * 0.90
            );
        }
        wireGroup.add(new Konva.Line({
            points: wavePts, stroke: poleColor, strokeWidth: 2,
            lineCap: 'round', lineJoin: 'round', tension: 0.3,
        }));
        wireGroup.add(new Konva.Line({
            points: [px, boxMidY + bW * 0.45, px, boxBot - 3],
            stroke: poleColor, strokeWidth: 2, lineCap: 'round',
        }));
        this._dynamicGroup.add(wireGroup);
        this._schFuseWire = wireGroup;

        const breakGroup = new Konva.Group({ visible: state === 'blown', listening: false });
        breakGroup.add(new Konva.Line({
            points: [px, boxTop + 3, px, boxMidY - bW * 0.60],
            stroke: '#808088', strokeWidth: 2, lineCap: 'round',
        }));
        breakGroup.add(new Konva.Line({
            points: [px, boxMidY + bW * 0.60, px, boxBot - 3],
            stroke: '#808088', strokeWidth: 2, lineCap: 'round',
        }));
        const xS = bW * 0.28;
        [[-xS, -xS, xS, xS], [xS, -xS, -xS, xS]].forEach(pts => {
            breakGroup.add(new Konva.Line({
                points: [px + pts[0], boxMidY + pts[1], px + pts[2], boxMidY + pts[3]],
                stroke: '#ff4030', strokeWidth: 2, lineCap: 'round',
            }));
        });
        breakGroup.add(new Konva.Circle({
            x: px, y: boxMidY, radius: bW * 0.18,
            fill: 'rgba(255,80,20,0.30)',
        }));
        this._dynamicGroup.add(breakGroup);
        this._schFuseBreak = breakGroup;
    }

    _updateDynamic() {
        const blown = this._states[0] === 'blown';
        this._schFuseWire.visible(!blown);
        this._schFuseBreak.visible(blown);

        this._arcGroup.destroyChildren();
        this._arcFrames.forEach((f, i) => {
            if (f > 0) this._drawBlowArc(this._arcGroup, i);
        });
    }

    _drawBlowArc(group, poleIdx) {
        const px = this._cx;
        const midY = (this._boxTop + this._boxBot) / 2;
        group.add(new Konva.Circle({
            x: px, y: midY,
            radius: this._boxW * 0.35 * (0.6 + Math.random() * 0.5),
            fill: `rgba(255,200,80,${0.3 + Math.random() * 0.3})`, listening: false,
        }));
    }

    _bindInteraction() {
        const hitArea = new Konva.Rect({
            x: this._cx - this._boxW / 2 - 4, y: this._boxTop - 4,
            width: this._boxW + 8, height: this._boxH + 8,
            fill: 'transparent',
        });
        hitArea.on('mouseenter', () => { document.body.style.cursor = 'pointer'; });
        hitArea.on('mouseleave', () => { document.body.style.cursor = 'default'; });
        this._interactGroup.add(hitArea);
    }

    tick(dt) {
        // ── 电流计算 + 过流自保护 ──
        // 电流由求解器按熔断器两端 0.01Ω 压降回填（physCurrent）；不能用
        // getVoltageBetween 直接读，因 0.01Ω 与回路其它阻抗并联时压降近零。
        if (this._states[0] === 'ok') {
            const solver = this.sys?.voltageSolver;
            if (solver) {
                if (this.physCurrent === undefined) {
                    const cL = solver.portToCluster.get(`${this.id}_wire_l`);
                    const cT = solver.portToCluster.get(`${this.id}_wire_t`);
                    if (cL !== undefined && cT !== undefined) {
                        this.physCurrent = ((solver.nodeVoltages.get(cL) || 0) - (solver.nodeVoltages.get(cT) || 0)) / 0.01;
                    }
                }
                // 过流熔断：正常过流按物理电流判别；此外，被保护回路存在"近零阻抗
                // 短路元件"（如接触器线圈被注入 0.001Ω）时，短路电流受变压器内阻抗
                // 限制、熔断器压降不显著，故补充按回路短路判据直接熔断。
                const overcurrent = Math.abs(this.physCurrent) > this.ratedCurrent * 1.2;
                const shortInLoop = this._loopHasShort();
                if (overcurrent || shortInLoop) {
                    this.blow(0);
                }
            }
        }

        let dirty = false;
        this._blowAnim.forEach((f, i) => { if (f > 0) { this._blowAnim[i]--; dirty = true; } });
        this._arcFrames.forEach((f, i) => { if (f > 0) { this._arcFrames[i]--; dirty = true; } });
        if (dirty) { this._updateDynamic(); this.markDirty(); }
        this._refreshIfDirty();
    }

    blow(pole = 0) {
        pole = Math.max(0, Math.min(this._poleCount - 1, parseInt(pole)));
        if (this._states[pole] === 'blown') return;
        this._states[pole]    = 'blown';
        this._blowAnim[pole]  = this._blowFrames;
        this._arcFrames[pole] = 5;
        this.opsCount++;
        this._updateDynamic();
        this.markDirty();
    }

    replace(pole = 0) {
        pole = Math.max(0, Math.min(this._poleCount - 1, parseInt(pole)));
        if (this._states[pole] === 'ok') return;
        this._states[pole] = 'ok';
        this._blowAnim[pole]  = 0;
        this._arcFrames[pole] = 0;
        this.opsCount++;
        this._updateDynamic();
        this.markDirty();
    }

    getState()    { return this._states[0]; }
    isBlown()     { return this._states[0] === 'blown'; }
    getOpsCount() { return this.opsCount; }

    /** 被保护的控制回路中是否存在近零阻抗短路元件（接触器线圈电阻被注入为 0.001Ω） */
    _loopHasShort() {
        // 仅副边熔断器（FU5）承担"控制回路短路"保护职责：短路电流由 FU5 切断。
        // 一次侧熔断器 FU4 不参与该判据，避免级联误熔断。
        if (this.id !== 'fu5') return false;
        const comps = this.sys?.comps;
        if (!comps) return false;
        for (const k in comps) {
            const c = comps[k];
            if (c && c.type === 'ContactorDevice' && c.special === 'contactcoil'
                && c._coilResistance !== undefined && c._coilResistance < 0.01) {
                // 线圈回路得电（线圈两端有电压）时才熔断
                const v = this.sys.getVoltageBetween?.(`${c.id}_wire_a1`, `${c.id}_wire_a2`) || 0;
                if (Math.abs(v) > 20) return true;
            }
        }
        return false;
    }

    update(state) {
        const v = String(state).toLowerCase();
        if (v === 'blown' || v === '0') this.blow(0);
        else this.replace(0);
    }

    getConfigFields() {
        return [
            { label: '位号/名称',    key: 'label',        type: 'text'   },
            { label: '额定电压 (V)', key: 'ratedVoltage', type: 'number' },
            { label: '额定电流 (A)', key: 'ratedCurrent', type: 'number' },
            { label: '熔断器型号',   key: 'fuseType',     type: 'text'   },
        ];
    }

    onConfigUpdate(cfg) {
        if (cfg.label        !== undefined) this.label        = cfg.label;
        if (cfg.ratedVoltage !== undefined) this.ratedVoltage = parseFloat(cfg.ratedVoltage);
        if (cfg.ratedCurrent !== undefined) this.ratedCurrent = parseFloat(cfg.ratedCurrent);
        if (cfg.fuseType     !== undefined) this.fuseType     = cfg.fuseType;
        this.config = { ...this.config, ...cfg };
        this._recalcGeometry();
        this._staticGroup.destroyChildren();
        this._dynamicGroup.destroyChildren();
        this._drawStaticParts();
        this._createDynamicNodes();
        this._refreshCache();
    }

    showContextMenu(evt) {
        const oldMenu = document.getElementById('comp-context-menu');
        if (oldMenu) oldMenu.remove();

        const menu = document.createElement('div');
        menu.id = 'comp-context-menu';
        menu.style = `position: fixed; top: ${evt.clientY}px; left: ${evt.clientX}px;
            background: white; border: 1px solid #ccc; border-radius: 4px;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.2); z-index: 10000;
            padding: 5px 0; min-width: 120px; font-family: sans-serif; font-size: 14px;`;

        const createItem = (label, onClick) => {
            const item = document.createElement('div');
            item.innerText = label;
            item.style = 'padding: 8px 15px; cursor: pointer; transition: background 0.2s;';
            item.onmouseenter = () => item.style.background = '#f0f0f0';
            item.onmouseleave = () => item.style.background = 'transparent';
            item.onclick = () => { onClick(); menu.remove(); };
            return item;
        };

        menu.appendChild(createItem('向右旋转 90°', () => this.rotate(90)));
        menu.appendChild(createItem('向左旋转 90°', () => this.rotate(-90)));
        menu.appendChild(createItem('参数设置', () => this.showConfigDialog()));

        const isBlown = this._states[0] === 'blown';
        menu.appendChild(createItem(isBlown ? '更换熔断器' : '模拟熔断', () => {
            isBlown ? this.replace(0) : this.blow(0);
        }));

        this.sys.container.appendChild(menu);
        const closeMenu = () => { menu.remove(); window.removeEventListener('click', closeMenu); };
        window.addEventListener('click', closeMenu);
    }

    destroy() { super.destroy?.(); }
}
