/**
 * CircuitTopology.js
 * 拓扑构建：并查集 + 零电阻短接 → Cluster 映射
 */

export class CircuitTopology {
    /**
     * @param {object[]} rawDevices  所有器件数组
     * @param {object[]} connections 导线连接数组（type === 'wire'）
     */
    build(rawDevices, connections, poorContactPorts = new Set(), faultShortGroups = []) {
        const parent = {};
        const find = (i) => (parent[i] === undefined || parent[i] === i) ? i : (parent[i] = find(parent[i]));
        const union = (i, j) => {
            const rI = find(i), rJ = find(j);
            if (rI !== rJ) parent[rI] = rJ;
        };

        // 1. 只收集有连线的端口（接触不良的端口不参与 union）
        const activePorts = new Set();
        connections.forEach(c => {
            activePorts.add(c.from);
            activePorts.add(c.to);
            if (!poorContactPorts.has(c.from) && !poorContactPorts.has(c.to))
                union(c.from, c.to);
        });

        // 1b. 故障注入短路：把指定端口强制合并为同一簇（模拟相间短路）
        // faultShortGroups 形如 [['port_a','port_b'], ['x','y','z']]，每组内所有端口
        // 即使无导线也视为同一导电节点；短路端口须先登记为活动端口，
        // 否则未连线端口不参与后续拓扑构建。
        faultShortGroups.forEach(group => {
            if (!Array.isArray(group) || group.length < 2) return;
            group.forEach(p => activePorts.add(p));
            const root0 = group[0];
            for (let k = 1; k < group.length; k++) union(root0, group[k]);
        });

        // 2. 器件内部的零电阻短接逻辑（只有两端都有连线才 union）
        rawDevices.forEach(dev => {
            const id = dev.id;
            const internalUnion = (p1, p2) => {
                if (activePorts.has(p1) && activePorts.has(p2)) union(p1, p2);
            };
            // 开关：闭合状态下左右端短接
            if (dev.type === 'switch' && dev.isOn)
                internalUnion(`${id}_wire_l`, `${id}_wire_r`);
            // 压力水柜液位控制器：两个干接点
            //   低压动作常开触头 lo_com/lo_no：液位低于低压设定值闭合（低于=合），高于断开；
            //   高压动作常闭触头 hi_com/hi_nc：液位高于高压设定值断开（高于=断），低于闭合。
            //   触头状态由组件 _lowClosed / _highClosed 维护（无回差）。
            if (dev.type === 'pressure_water_tank') {
                if (dev._lowClosed) internalUnion(`${id}_wire_lo_com`, `${id}_wire_lo_no`);
                if (dev._highClosed) internalUnion(`${id}_wire_hi_com`, `${id}_wire_hi_nc`);
            }
            // SPNT 开关（单刀多掷）：根据 _position 短接 COM 与对应端子
            if (dev.type === 'SPNT' && dev._position !== undefined)
                internalUnion(`${id}_wire_com`, `${id}_wire_t${dev._position}`);
            // SmartAnalogSwitch：根据 position 短接 COM 与对应端子（功能型 SP4T）
            if (dev.type === 'smart_switch' && dev.position !== undefined)
                internalUnion(`${id}_wire_com`, `${id}_wire_t${dev.position}`);
            // 万能转换开关：根据凸轮表短路每对触点 L-R
            if (dev.type === 'uniswitch' && dev._pairClosed !== undefined) {
                dev._pairClosed.forEach((closed, i) => {
                    if (closed) internalUnion(`${id}_wire_p${i+1}l`, `${id}_wire_p${i+1}r`);
                });
            }
            if (dev.type === 'relay' && (dev.special === 'voltage' && dev.contactFault===false)) {
                if (dev.isEnergized) internalUnion(`${id}_wire_NO`, `${id}_wire_COM`);
                else internalUnion(`${id}_wire_NC`, `${id}_wire_COM`);
            }            
            if (dev.type === 'relay' && dev.special === 'wtrelay') {
                if (dev.isEnergized) internalUnion(`${id}_wire_NC`, `${id}_wire_COM`);
                else internalUnion(`${id}_wire_NO`, `${id}_wire_COM`);
            }
            // 压力继电器：励磁（压力低于下限）时 NC-COM 闭合（压缩机控制触点）；
            // 释放（压力高于上限）时 NO-COM 闭合。用于压力开关控制压缩机启停。
            if (dev.type === 'relay' && dev.special === 'pressrelay') {
                if (dev.isEnergized) internalUnion(`${id}_wire_NC`, `${id}_wire_COM`);
                else internalUnion(`${id}_wire_NO`, `${id}_wire_COM`);
            }
            // 逆功率继电器：未动作(含延时中) NC-COM 闭合；跳闸后 NO-COM 闭合
            if (dev.type === 'relay' && dev.special === 'REV-POWER') {
                if (dev._state === 'tripped') internalUnion(`${id}_wire_NO`, `${id}_wire_COM`);
                else internalUnion(`${id}_wire_NC`, `${id}_wire_COM`);
            }
            // PT100 传感器：在三线制等特定配置下，补偿端(t)与信号端(r)通常在根部短接
            if (dev.special === 'pt100')
                internalUnion(`${id}_wire_r`, `${id}_wire_t`);
            // 高压放电棒：接地线引出点(r) 与 接地线末端(gnd) 内部短接，并强制登记
            // 两端口（连接处端口通常无外部连线），保证 钩端(l) → 10MΩ → 地 的通路
            // 始终成立：l—r 由 DeviceStamps 按 resistor 填充，r—gnd 零电阻短接；
            // 若 gnd 未接 Ground 组件，则 r+gnd 构成悬空簇，行为等同普通未接地电阻，无害。
            if (dev.type === 'resistor' && dev.special === 'hv_discharge') {
                activePorts.add(`${id}_wire_r`);
                activePorts.add(`${id}_wire_gnd`);
                internalUnion(`${id}_wire_r`, `${id}_wire_gnd`);
            }
            // 高压接地线（三相短路接地线）：三个相接线夹(p1/p2/p3)与接地夹(gnd)
            // 内部短接（三根接地软线 + 短接连片零电阻），强制登记四端口：
            // 只夹一相时该相即经 接地夹 对地短接（与实物一致）；全部未接线时
            // 四端口构成悬空簇，不影响求解。
            if (dev.type === 'hv_grounding_lead') {
                const gid = `${id}_wire_gnd`;
                activePorts.add(gid);
                ['p1', 'p2', 'p3'].forEach(p => {
                    const pid = `${id}_wire_${p}`;
                    activePorts.add(pid);
                    internalUnion(gid, pid);
                });
            }
            // 低压临时接地线：与高压接地线相同的四端口（p1/p2/p3/gnd）内部零电阻短接，
            // 三相在接地夹处短接到大地。强制登记四端口：全部未接线时构成悬空簇，不影响求解。
            if (dev.type === 'lv_grounding_lead') {
                const gid = `${id}_wire_gnd`;
                activePorts.add(gid);
                ['p1', 'p2', 'p3'].forEach(p => {
                    const pid = `${id}_wire_${p}`;
                    activePorts.add(pid);
                    internalUnion(gid, pid);
                });
            }
            // UPS：输出中性线与输入中性线内部共地（避免输出浮动子网导致 MNA 奇异）
            if (dev.type === 'ups') {
                internalUnion(`${id}_wire_in_n`, `${id}_wire_out1_n`);
                internalUnion(`${id}_wire_in_n`, `${id}_wire_out2_n`);
            }

            // 起动按钮（NO常开）：按下或模拟闭合时短接
            if (dev.type === 'PUSHBUTTON' && dev.special === 'START-BTN' && (dev._isPressed || dev._manualPressed))
                internalUnion(`${id}_wire_no1`, `${id}_wire_no2`);

            // 发电机组遥控面板：START/STOP 按住时短接对应端口对
            if (dev.type === 'gen_remote_panel') {
                if (dev._startPressed) internalUnion(`${id}_wire_start_a`, `${id}_wire_start_b`);
                if (dev._stopPressed)  internalUnion(`${id}_wire_stop_a`,  `${id}_wire_stop_b`);
                // 高压发电机遥控面板（HvGenRemotePanel）：停机后灭磁触点闭合
                if (dev._demagClosed)  internalUnion(`${id}_wire_demag_a`, `${id}_wire_demag_b`);
            }

            // 应急配电板：起动/停止信号短接对应端口对
            if (dev.type === 'emergency_panel') {
                if (dev._out && dev._out.genStart) internalUnion(`${id}_wire_egen_start_a`, `${id}_wire_egen_start_b`);
                if (dev._out && dev._out.genStop)  internalUnion(`${id}_wire_egen_stop_a`,  `${id}_wire_egen_stop_b`);
            }

            // 停止按钮（NC常闭）：未按下（含模拟按下 _manualPressed）且未故障时短接
            if (dev.type === 'PUSHBUTTON' && dev.special === 'STOP-BTN'
                && !dev._isPressed && !dev._manualPressed && !dev._faultOpen)
                internalUnion(`${id}_wire_nc3`, `${id}_wire_nc4`);

            // S7-200 SMART（晶体管源型输出）：某输出位 Q=1 时，对应输出端 dqXX
            // 与输出负载电源正端 1L+（Q0.x~Q1.3）/ 2L+（Q1.4 起）内部导通（输出 24V）；
            // Q=0 时输出端高阻，不合并（负载/线圈自身经由 0V 构成回路）。
            // _qBits 由 tools/S7200Solver.js 每个扫描周期回填。
            if (dev.type === 'plc_s7200' && Array.isArray(dev._qBits) && Array.isArray(dev.dqPins)) {
                dev.dqPins.forEach((pin, i) => {
                    if (!dev._qBits[i]) return;
                    const bitNum = parseInt(String(pin).replace(/^dq/, ''), 10);
                    const lpos = (bitNum < 14) ? '1l' : '2l';
                    internalUnion(`${id}_wire_${pin}`, `${id}_wire_${lpos}`);
                });
            }

            // S7-200 SMART 数字量输出扩展模块（EM DQ08，晶体管源型）：
            // 某路 Q=1 时，该路输出端 dqN 与负载电源正端 1L+ 内部导通（输出 24V）。
            if (dev.type === 's7200_dq08' && Array.isArray(dev._qOut)) {
                dev._qOut.forEach((on, n) => {
                    if (on) internalUnion(`${id}_wire_dq${n}`, `${id}_wire_1l`);
                });
            }

            // 扩展模块挂接后的内部公共连接（无需外部接线）：
            //   EM DI08 公共端 1M ↔ CPU 的 0V（传感器电源负）
            //   EM DQ08 负载电源 1L+ ↔ CPU 的 24V（传感器电源正）
            // 强制登记两端端口，保证未外部接线时该内部连接依然有效。
            if (dev.type === 's7200_di08' && dev._cpu && dev._cpu.id) {
                const p1 = `${id}_wire_com`, p2 = `${dev._cpu.id}_wire_v0`;
                activePorts.add(p1); activePorts.add(p2); union(p1, p2);
            }
            if (dev.type === 's7200_dq08' && dev._cpu && dev._cpu.id) {
                const p1 = `${id}_wire_1l`, p2 = `${dev._cpu.id}_wire_24v`;
                activePorts.add(p1); activePorts.add(p2); union(p1, p2);
            }

            // 热继电器：主电路 L-T 由 DeviceStamps 作小电阻处理，不在此短接
            // 辅助触头：NC 未跳脱时闭合，NO 跳脱时闭合
            if (dev.type === 'relay' && dev.special === 'time') {
                if (dev._state === 'output') {
                    internalUnion(`${id}_wire_no_a`, `${id}_wire_com_a`);
                    internalUnion(`${id}_wire_com_b`, `${id}_wire_no_b`);
                } else {
                    internalUnion(`${id}_wire_nc_a`, `${id}_wire_com_a`);
                    internalUnion(`${id}_wire_com_b`, `${id}_wire_nc_b`);
                }
            }

            if (dev.type === 'RELAY' && dev.special === 'THERMAL-OL-RELAY') {
                if (dev._state !== 'tripped') {
                    internalUnion(`${id}_wire_nc_a`, `${id}_wire_nc_b`);
                } else {
                    internalUnion(`${id}_wire_no_a`, `${id}_wire_no_b`);
                }
            }

            // 铅酸蓄电池：仅当有接线时才注册内部端口（防止未接线电池产生浮动节点）
            if (dev.type === 'leadacid_battery') {
                let hasConnection = false;
                for (let i = 1; i <= 6 && !hasConnection; i++) {
                    if (activePorts.has(`${id}_wire_cell${i}_p`) || activePorts.has(`${id}_wire_cell${i}_n`)) hasConnection = true;
                }
                if (hasConnection) {
                    for (let i = 1; i <= 6; i++) {
                        activePorts.add(`${id}_wire_cell${i}_p`);
                        activePorts.add(`${id}_wire_cell${i}_n`);
                    }
                    for (let i = 1; i < 6; i++) {
                        internalUnion(`${id}_wire_cell${i}_n`, `${id}_wire_cell${i + 1}_p`);
                    }
                }
            }

            // 三相交流接触器：吸合时短接主触点和 NO 触点，释放时短接 NC 触点
            if (dev.type === 'CONTACTOR') {
                const isOn = dev._state === 'on';
                if (isOn) {
                    if (!dev._faultContactL1T1) internalUnion(`${id}_wire_l1`, `${id}_wire_t1`);
                    internalUnion(`${id}_wire_l2`, `${id}_wire_t2`);
                    internalUnion(`${id}_wire_l3`, `${id}_wire_t3`);
                    if (!dev._faultContactNO1) internalUnion(`${id}_wire_no1a`, `${id}_wire_no1b`);
                    internalUnion(`${id}_wire_no2a`, `${id}_wire_no2b`);
                } else {
                    internalUnion(`${id}_wire_nc1a`, `${id}_wire_nc1b`);
                    internalUnion(`${id}_wire_nc2a`, `${id}_wire_nc2b`);
                }
            }

            // 空气断路器（ACB，含联络开关/船用主开关）辅助触点：
            //   NO 常开触点（no1/no2）：合闸闭合、分闸断开
            //   NC 常闭触点（nc1/nc2）：分闸闭合、合闸断开
            if (dev.type === 'ACB') {
                const acbOn = dev._state === 'on';
                if (dev.ports) {
                    const pid = (n) => `${id}_wire_${n}`;
                    const has = (n) => dev.ports.some(p => p.id === n || p.id === pid(n));
                    if (has('no1')) {
                        if (acbOn) internalUnion(pid('no1'), pid('no2'));
                    }
                    if (has('nc1')) {
                        if (!acbOn) internalUnion(pid('nc1'), pid('nc2'));
                    }
                }
                // 接地开关闭合：T1/T2/T3 出线侧与内部虚拟地短接（与地同簇）
                if (typeof dev.isGrounded === 'function' ? dev.isGrounded() : (dev._gsClosed === true)) {
                    ['t1', 't2', 't3'].forEach(p => {
                        const tid = `${id}_wire_${p}`;
                        const gid = `${id}_wire_gnd`;
                        activePorts.add(tid);
                        activePorts.add(gid);
                        internalUnion(tid, gid);
                    });
                } else {
                    // 未接地时仅登记端口（不合并，端口保持独立）
                    ['t1', 't2', 't3'].forEach(p => activePorts.add(`${id}_wire_${p}`));
                }
            }

            // SINAMICS V20 变频器：数字量输出触点按运行状态内部短接
            //   DO1（晶体管）运行中闭合；DO2（继电器）故障时闭合
            if (dev.type === 'v20_inverter') {
                if (dev._do1On) internalUnion(`${id}_wire_do1p`, `${id}_wire_do1n`);
                if (dev._do2On) internalUnion(`${id}_wire_do2c`, `${id}_wire_do2no`);
            }

            // 三相汇流排：同一相位铜条上所有已连线端口短接为同一节点
            // （仅 union 有连线的端口，未接线端口不产生浮动节点）
            if (dev.type === 'busbar_3p') {
                const n = dev._portsPerBar || 8;
                ['l1', 'l2', 'l3'].forEach(ph => {
                    let first = null;
                    for (let i = 1; i <= n; i++) {
                        const pid = `${id}_wire_${ph}_${i}`;
                        if (activePorts.has(pid)) {
                            if (first === null) first = pid;
                            else internalUnion(first, pid);
                        }
                    }
                });
            }


        });

        // 2b. 【CAN 总线连接器：全局跨器件同簇】
        //     所有 BusConnector 子组件的 canhL/canhR/canh 并入同一簇，
        //     canlL/canlR/canl 并入同一簇；这样任意 CAN 设备只要把 can1p/can1n
        //     接到某个连接器上方的 canh/canl，就等同于挂接到整条总线上，
        //     各连接器之间无需再拉线互联。
        let busHPort = null, busLPort = null;
        const busCons = rawDevices.filter(d => d && d.type === 'bus_connector');
        if (busCons.length) {
            const H_PORTS = ['canhL', 'canhR', 'canh'];
            const L_PORTS = ['canlL', 'canlR', 'canl'];
            // 强制登记全部 6 个端口（未接线也要纳入簇，保证 L/R 互联语义成立）
            busCons.forEach(c => {
                [...H_PORTS, ...L_PORTS].forEach(p => activePorts.add(`${c.id}_wire_${p}`));
            });
            busHPort = `${busCons[0].id}_wire_canh`;
            busLPort = `${busCons[0].id}_wire_canl`;
            busCons.forEach(c => {
                H_PORTS.forEach(p => union(busHPort, `${c.id}_wire_${p}`));
                L_PORTS.forEach(p => union(busLPort, `${c.id}_wire_${p}`));
            });
        }

        // 2c. 【跨页连接器：同 deviceid、同通道号全局同簇】
        //     多页面画布下连线只在两端同页时显示；跨页信号通过 PageLink 端子
        //     互通：相同 deviceid 的 PageLink 组件，其 a{i}/b{i} 端口全局同簇。
        const pageLinks = rawDevices.filter(d => d && d.type === 'page_link');
        if (pageLinks.length) {
            const byLink = new Map();
            pageLinks.forEach(c => {
                const key = c.deviceid || 'XPL';
                if (!byLink.has(key)) byLink.set(key, []);
                byLink.get(key).push(c);
            });
            byLink.forEach((list) => {
                const pairs = list.reduce((mx, c) => Math.max(mx, c._pairs || 12), 0);
                for (let i = 1; i <= pairs; i++) {
                    ['a', 'b'].forEach(side => {
                        let root = null;
                        list.forEach(c => {
                            const pid = `${c.id}_wire_${side}${i}`;
                            activePorts.add(pid);          // 强制登记：即使某页只接一端也能同簇
                            if (root === null) root = pid;
                            else union(root, pid);
                        });
                    });
                }
            });
        }

        // 3. 【全局合并所有地】所有 Ground 组件与同步表的接地端视为同一节点
        let firstGnd = null;
        rawDevices.forEach(dev => {
            if (dev.type === 'gnd' || dev.type === 'syncroscope' || dev.type === 'lampRotationSync') {
                const pid = `${dev.id}_wire_gnd`;
                if (activePorts.has(pid)) {
                    if (firstGnd === null) firstGnd = pid;
                    else union(firstGnd, pid);
                }
            }
            // 真空断路器接地开关闭合：其内部虚拟地端口并入全局地
            if (dev.type === 'ACB' && typeof dev.isGrounded === 'function' && dev.isGrounded()) {
                const pid = `${dev.id}_wire_gnd`;
                if (activePorts.has(pid)) {
                    if (firstGnd === null) firstGnd = pid;
                    else union(firstGnd, pid);
                }
            }
        });

        // 4. 【内置端口】MOTOR / motor_winding 等器件的内部端口始终纳入拓扑（即使未接线）
        rawDevices.forEach(dev => {
            if (dev.type === 'MOTOR') {
                ['l1', 'l2', 'l3', 'pe'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'motor_winding') {
                ['u1','u2','v1','v2','w1','w2'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'induction_motor') {
                ['u1','u2','v1','v2','w1','w2'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'motor_3d') {
                // 三相电机 3D：U/V/W 与 PE 端口始终纳入拓扑，
                // 保证每相对地（PE 星点）注入的阻抗支路即使 PE 未接线也成立
                ['u', 'v', 'w', 'pe'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'source_3p') {
                ['u', 'v', 'w', 'n'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'v20_inverter') {
                // 变频器三相输出端口与内部中性点始终纳入拓扑，
                // 保证 U/V/W 输出 stamp 即使未接线也能建立（n 为内部参考）
                ['u', 'v', 'w', 'n'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'ACB') {
                ['l1','l2','l3','t1','t2','t3','fla','flb'].forEach(p =>
                    activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'motor_control_box') {
                // 电机控制箱：12 个接线端子端口 + PE 网络 + 内部中性点 n 始终纳入拓扑，
                // 保证上下排同簇、接触器吸合左右同簇恒成立（即使端口未接线）
                ['in1','in2','in3','inU','inV','inW','outU','outV','outW','out1','out2','out3','n']
                    .forEach(p => activePorts.add(`${dev.id}_wire_${p}`));
                ['pe1','pe2','pe3','pe4','pe_body','pe_door']
                    .forEach(p => activePorts.add(`${dev.id}_wire_${p}`));
            }
            if (dev.type === 'ground_bus') {
                // 接地母排：所有接线柱端口一律纳入拓扑（即使未接线），保证同簇恒成立
                const n = (typeof dev.getTermCount === 'function') ? dev.getTermCount() : 4;
                for (let i = 1; i <= n; i++) activePorts.add(`${dev.id}_wire_pe${i}`);
            }
        });

        // 4b. 【内置器件内部同簇】对"端口须始终纳入拓扑并内部导通"的器件，
        // 在其端口全部登记为 activePorts（第 4 步）之后再做内部短接 union。
        // 关键：internalUnion 依赖 activePorts.has 守卫，必须等端口登记完毕才有效；
        // 否则未连线端口不会参与同簇合并（电机控制箱上下排/左右排即会各自孤立成簇）。
        rawDevices.forEach(dev => {
            const id = dev.id;
            const rawUnion = (p1, p2) => {
                if (activePorts.has(p1) && activePorts.has(p2)) union(p1, p2);
            };
            if (dev.type === 'motor_control_box') {
                // 左上下同簇：in1↔inU、in2↔inV、in3↔inW（电源进线 ↔ 空气开关入口，恒接）
                for (let i = 0; i < 3; i++) {
                    rawUnion(`${id}_wire_in${i + 1}`, `${id}_wire_in${['U', 'V', 'W'][i]}`);
                }
                // 右上下同簇：outU↔out1、outV↔out2、outW↔out3（热继电器出线 ↔ 对外引出，恒接）
                for (let i = 0; i < 3; i++) {
                    rawUnion(`${id}_wire_out${['U', 'V', 'W'][i]}`, `${id}_wire_out${i + 1}`);
                }
                // 接触器吸合 且 空气开关闭合：左入口与右上出线一一对应同簇（inU↔outU 等）
                const acbOn = dev._dualStates && dev._dualStates[1] === 'close';
                const isContactorOn = dev._dualStates && dev._dualStates[4] === 'close';
                if (acbOn && isContactorOn) {
                    for (let i = 0; i < 3; i++) {
                        rawUnion(`${id}_wire_in${['U', 'V', 'W'][i]}`, `${id}_wire_out${['U', 'V', 'W'][i]}`);
                    }
                }
                // PE 保护接地网络同簇：PE 端子组 4 端口 + 箱体 PE 点 + 门 PE 点
                const pePorts = ['pe1', 'pe2', 'pe3', 'pe4', 'pe_body', 'pe_door'];
                let peRoot = pePorts[0];
                pePorts.forEach((p, i) => {
                    if (i > 0) rawUnion(`${id}_wire_${peRoot}`, `${id}_wire_${p}`);
                });
            }
            if (dev.type === 'ground_bus') {
                // 接地母排：所有接线柱内部短接为同一节点（同簇），代表整条母排等电位
                const n = (typeof dev.getTermCount === 'function') ? dev.getTermCount() : 4;
                for (let i = 2; i <= n; i++) {
                    rawUnion(`${id}_wire_pe1`, `${id}_wire_pe${i}`);
                }
            }
        });

        // 数字万用表电阻/二极管档：V 和 COM 始终纳入拓扑（即使未接线），
        // 以便恒流源注入和顺从电压输出
        rawDevices.forEach(dev => {
            if (dev.type === 'multimeter' && dev.mode && (dev.mode.startsWith('RES') || dev.mode === 'DIODE')) {
                activePorts.add(`${dev.id}_wire_v`);
                activePorts.add(`${dev.id}_wire_com`);
            }
        });

        // 5. 【构建映射表】将物理端口名映射为数值索引 (Cluster Index)
        const portToCluster = new Map();// 键：端口名 (String)，值：节点索引 (Number)
        const clusterIndexMap = new Map();// 辅助：记录每个并查集根节点的唯一索引
        let idx = 0;
        activePorts.forEach(p => {
            const root = find(p);
            // 如果这个根节点还没分配索引，则分配一个新的递增索引
            if (!clusterIndexMap.has(root)) clusterIndexMap.set(root, idx++);
            // 将当前端口指向对应的索引
            portToCluster.set(p, clusterIndexMap.get(root));
        });
        // 总节点数（MNA 矩阵的大小将基于此值构建）
        const clusterCount = idx;

        // 4. 生成 clusters 集合（每个 cluster 是端口名的 Set）
        const clusterGroups = {};
        activePorts.forEach(p => {
            const root = find(p);
            if (!clusterGroups[root]) clusterGroups[root] = new Set();
            clusterGroups[root].add(p);
        });
        // 转化为数组格式：[[port1, port2], [port3, port4], ...]
        const clusters = Object.values(clusterGroups);

        return { portToCluster, clusterCount, clusters, busHPort, busLPort };
    }
}
