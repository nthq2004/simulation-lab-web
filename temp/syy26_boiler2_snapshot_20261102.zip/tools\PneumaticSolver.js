/**
 * 气路物理求解器
 * 负责根据拓扑连接和设备状态，计算全场压力分布
 */

export class PneumaticSolver {
    constructor(sys) {
        this.sys = sys;
        this.terminalPressures = {};
        this.topologyKey = null;
        this.cachedPressures = {};
        this.pressureEps = 1e-4;

        // 流量区域拓扑（由 _buildFlowZones 构建）
        this._flowZoneMap = {};   // portId → 'main'|'u_branch'|'l_branch'|'common'|'zero'
        this._pipeGraph = {};     // 管路连接邻接表
    }

    solve() {
        // 缓存泵 / 电动执行器引用，并判断是否需要流量区域仿真（无泵/无执行器则跳过）
        this._refs();
        this._runningPump = this._pickRunningPump();
        if (this._flowSimEnabled === undefined) {
            this._flowSimEnabled = !!(this._pumpRef || this._actuatorRef);
        }

        const currentTopologyKey = this._computeTopologyKey();
        // 压力源（气瓶压力等）每帧可能变化，需与连接拓扑一起决定是否重算压力场
        const sourceKey = this._computeSourceKey();
        const pressKey = currentTopologyKey + '||' + sourceKey;

        // ── 压力场重算：连接拓扑或压力源变化时 ──
        if (pressKey !== this._cachedPressKey) {
            this._cachedPressKey = pressKey;

            // ── 组件数组缓存（避免多次 Object.values）──
            const allComps = this.__allComps || (this.__allComps = Object.values(this.sys.comps));

            // ── 压力场 BFS ──
            const terminalPressures = {};
            const queue = [];
            const visitedPorts = new Set();

            allComps.forEach(device => {
                if (device.ports) {
                    device.ports.forEach(port => {
                        if (port.type === 'pipe') terminalPressures[port.id] = 0;
                    });
                }
            });

            // ── 压力源播种（气瓶 / 泵 / 执行器 / 校验仪，统一收集）──
            this._collectSources(allComps).forEach(src => {
                terminalPressures[src.portId] = src.pressure;
                queue.push(src.portId);
            });

            while (queue.length > 0) {
                const currentPortId = queue.shift();
                if (visitedPorts.has(currentPortId)) continue;
                visitedPorts.add(currentPortId);
                const currentP = terminalPressures[currentPortId];

                this.sys.conns.forEach(conn => {
                    if (conn.type !== 'pipe') return;
                    let nextPortId = null;
                    if (conn.from === currentPortId) nextPortId = conn.to;
                    else if (conn.to === currentPortId) nextPortId = conn.from;

                    if (nextPortId) {
                        terminalPressures[nextPortId] = currentP;

                        const compId = nextPortId.includes('_pipe_') ? nextPortId.split('_pipe_')[0]
                            : nextPortId.includes('_wire_') ? nextPortId.split('_wire_')[0]
                            : nextPortId.split('_')[0];
                        const comp = this.sys.comps[compId];
                        if (comp) {
                            const port = comp.ports.find(p => p.id === nextPortId);
                            if (port && port.node && port.node.getAttr && port.node.getAttr('isLeaking')) {
                                // 确定性漏气损失（按端口 id 哈希），避免读数随机抖动
                                const lossRatio = 0.2 + this._hash01(nextPortId) * 0.1;
                                terminalPressures[nextPortId] = Math.max(0, currentP * (1 - lossRatio));
                            }
                        }

                        const deviceId = this._getDeviceIdFromPort(nextPortId);
                        const device = this.sys.comps[deviceId];
                        if (device) {
                            this._processInternalTransfer(device, nextPortId, terminalPressures, queue);
                        }
                    }
                });
            }

            this.terminalPressures = terminalPressures;

            const pressuresChanged = this._pressuresChanged(this.cachedPressures, terminalPressures);
            const topologyChanged = currentTopologyKey !== this.topologyKey;
            if (topologyChanged || pressuresChanged) {
                this.topologyKey = currentTopologyKey;
                this.cachedPressures = Object.assign({}, terminalPressures);
                this._syncDevices();
            }

            // ── 仅在连接/开关拓扑变化、且存在泵/执行器流量源时重建流量区域 ──
            if (this._flowSimEnabled && currentTopologyKey !== this._cachedFlowKey) {
                this._cachedFlowKey = currentTopologyKey;
                this._buildFlowZones();
            }
        }

        // ── 设备流量更新（每帧执行，捕捉 pumpFlow / valvePos 实时变化）──
        if (this._flowSimEnabled) this._updateDeviceFlows();
        // ── 压缩机充气：运转中且排气口接至气瓶时，逐帧为气瓶充气 ──
        this._updateCompressors();
    }

    /**
     * 设备状态同步（仅压力相关设备）
     */
    _syncDevices() {
        const pressures = this.terminalPressures;
        const targetTypes = ['pressSwitch', 'pressMeter', 'regulator',
            'pressure_sensor', 'pressure_transducer', 'calibrator'];

        const allComps = this.__allComps || Object.values(this.sys.comps);
        allComps.forEach(device => {
            if (targetTypes.includes(device.type)) {
                const inPortId = `${device.id}_pipe_i`;
                const currentP = pressures[inPortId] || 0;

                if (device.type === 'calibrator') {
                    // 校验仪气压测量：求解器用 MPa，显示用 kPa
                    const kpa = currentP * 1000;
                    if (device.upMode === 'MEAS_PRESSURE') {
                        device.upPressureValue = kpa;
                    }
                    if (device.activePanel === 'MEASURE' && device.measureMode === 'MEAS_PRESSURE') {
                        device.downPressureValue = kpa;
                    }
                    return;
                }

                if (device.update) {
                    if (device.type === 'regulator') {
                        device.inputPressure = currentP;
                        device.update();
                    } else {
                        device.update(currentP);
                    }
                }
            } else if (device.special === 'pressrelay' && device.update) {
                // 压力继电器：取进气口压力，驱动触点动作（isEnergized → NC/NO 通断）
                const inPortId = `${device.id}_pipe_i`;
                device.update(pressures[inPortId] || 0);
            }
        });
    }

    /**
     * 构建流量区域拓扑
     *
     * 根据管路连接图，将每个 pipe 端口归类到以下区域之一：
     *   'main'     — 干路（泵出口到三通之间）
     *   'u_branch' — u 支路（最终汇入调节阀 u 口）
     *   'l_branch' — l 支路（最终汇入调节阀 l 口）
     *   'common'   — 公共回路（从调节阀 r 口出发）
     *   'zero'     — 未连接任何源
     *
     * 方法：构建端口无向图 → 连通分量分析 → 以调节阀三端口 + 泵出口为锚点分类
     */
    _buildFlowZones() {
        this._flowZoneMap = {};

        // ── 1. 构建管路端口邻接表 ──
        const graph = {};
        this.sys.conns.forEach(conn => {
            if (conn.type !== 'pipe') return;
            if (!graph[conn.from]) graph[conn.from] = [];
            if (!graph[conn.to]) graph[conn.to] = [];
            graph[conn.from].push(conn.to);
            graph[conn.to].push(conn.from);
        });
        this._pipeGraph = graph;

        // ── 2. 关键设备（缓存引用，避免每帧 Object.values().find）──
        this._refs();
        const pumps = this._pumps || [];
        const pumpOutPorts = new Set(pumps.map(p => `${p.id}_pipe_o`));
        const pump = this._pickRunningPump();

        const elecValve = this._actuatorRef;
        const vU = elecValve ? `${elecValve.id}_pipe_u` : null;
        const vL = elecValve ? `${elecValve.id}_pipe_l` : null;
        const vR = elecValve ? `${elecValve.id}_pipe_r` : null;

        // ── 3. 连通分量 BFS ──
        const visited = new Set();
        const graphKeys = Object.keys(graph);
        const comps = [];

        graphKeys.forEach(startPort => {
            if (visited.has(startPort)) return;

            const ports = [];
            const queue = [startPort];
            while (queue.length > 0) {
                const curr = queue.shift();
                if (visited.has(curr)) continue;
                visited.add(curr);
                ports.push(curr);
                for (const nb of (graph[curr] || [])) {
                    if (!visited.has(nb)) queue.push(nb);
                }
            }

            const portSet = new Set(ports);
            let zone = 'zero';
            if (vR && portSet.has(vR)) {
                zone = 'common';
            } else if (vU && portSet.has(vU)) {
                zone = 'u_branch';
            } else if (vL && portSet.has(vL)) {
                zone = 'l_branch';
            } else if (pumpOutPorts.size && [...pumpOutPorts].some(pp => portSet.has(pp))) {
                zone = 'main';
            }
            if (zone === 'zero' && !elecValve && pumps.length === 0) zone = 'main';
            if (zone === 'zero' && pumps.length > 0 && !elecValve) zone = 'main';

            comps.push({ ports, zone });
            ports.forEach(pid => { this._flowZoneMap[pid] = zone; });
        });

        // ── 4. 通过内联设备传播 u_branch / l_branch ──
        //    内联设备：流量计、冷却器等（非三通/调节阀/发动机/泵）
        const boundaryTypes = new Set(['teeConnector', 'engine', 'Pump']);

        let changed = true;
        while (changed) {
            changed = false;
            for (const comp of comps) {
                if (comp.zone !== 'zero') continue;
                const compSet = new Set(comp.ports);

                for (const portId of comp.ports) {
                    const devId = portId.split('_pipe_')[0];
                    const dev = this.sys.comps[devId];
                    if (!dev || !dev.ports || boundaryTypes.has(dev.type)) continue;
                    // 检查 ElecValve（actuator）也属于边界
                    if (dev.type === 'resistor' && dev.special === 'actuator') continue;

                    for (const op of dev.ports) {
                        if (op.type !== 'pipe' || compSet.has(op.id)) continue;
                        const otherZone = this._flowZoneMap[op.id];
                        if (otherZone === 'u_branch' || otherZone === 'l_branch') {
                            comp.zone = otherZone;
                            comp.ports.forEach(pid => { this._flowZoneMap[pid] = otherZone; });
                            changed = true;
                            break;
                        }
                    }
                    if (changed) break;
                }
            }
        }

        // ── 5. 重映射：common/zero → main ──
        for (const portId in this._flowZoneMap) {
            if (this._flowZoneMap[portId] === 'common' || this._flowZoneMap[portId] === 'zero') {
                this._flowZoneMap[portId] = 'main';
            }
        }

        // ── 6. 各泵的「专属管路」（停机泵的前后管路不应有流动）──
        this._buildPumpIslands();
    }

    /**
     * 计算每台泵的「专属管路」：从泵的吸入口/排出口出发，仅穿过内联管件
     * （单向阀/冷却器/滤器等），遇到三通/柴油机/其它泵等分支节点即停止。
     * 停机泵的专属管路在流量动画中置零，避免"不运行的泵前后也在流动"。
     */
    _buildPumpIslands() {
        this._pipeConnOwner = {};
        const boundary = new Set(['teeConnector', 'engine', 'Pump']);
        const ckey = (c) => `${c.from}|${c.to}|${c.type}`;
        for (const pump of (this._pumps || [])) {
            const queue = [`${pump.id}_pipe_i`, `${pump.id}_pipe_o`];
            const seen = new Set();
            while (queue.length) {
                const port = queue.shift();
                if (seen.has(port)) continue;
                seen.add(port);
                for (const conn of (this.sys.conns || [])) {
                    if (conn.type !== 'pipe') continue;
                    let other = null;
                    if (conn.from === port) other = conn.to;
                    else if (conn.to === port) other = conn.from;
                    if (!other) continue;
                    this._pipeConnOwner[ckey(conn)] = pump.id;
                    const devId = this._getDeviceIdFromPort(other);
                    const dev = this.sys.comps[devId];
                    if (!dev || boundary.has(dev.type)) continue;
                    dev.ports.forEach(p => { if (p.type === 'pipe') queue.push(p.id); });
                }
            }
        }
    }

    /** 该管路是否连接压力测量元件（压力开关/压力表/压力变送器）——测压支路不流动 */
    _touchesMeasure(conn) {
        const dev = (portId) => this.sys.comps[this._getDeviceIdFromPort(portId)];
        const isM = (d) => !!(d && (d.special === 'pressrelay'
            || d.type === 'pressMeter' || d.type === 'pressure_sensor' || d.type === 'pressure_transducer'));
        return isM(dev(conn.from)) || isM(dev(conn.to));
    }

    /**
     * 判断管路流向
     * @param {object} conn - { from, to, type }
     * @returns {number} 1 = conn.from→conn.to, -1 = conn.to→conn.from
     *
     * 规则：
     *   *_out / *_o → 从该端流出
     *   *_in  / *_i → 从另一端流入
     *   三通调节阀：_l/_u 流入，_r 流出
     */
    _pipeFlowDirection(conn) {
        const pf = conn.from, pt = conn.to;
        const portFrom = pf.split('_pipe_')[1] || '';
        const portTo   = pt.split('_pipe_')[1] || '';

        // ---- 三通调节阀 ElecValve 特殊规则 ----
        const devFrom = pf.split('_pipe_')[0];
        const devTo   = pt.split('_pipe_')[0];
        if (devFrom && devFrom === devTo) {
            const isL = portFrom === 'l' || portTo === 'l';
            const isU = portFrom === 'u' || portTo === 'u';
            const isR = portFrom === 'r' || portTo === 'r';
            if (isR && (isL || isU)) {
                return (portFrom === 'l' || portFrom === 'u') ? 1 : -1;
            }
        }

        // ---- 通用端口命名规则 ----
        const fromIsOut = /_(?:o|out)$/.test(pf);
        const toIsOut   = /_(?:o|out)$/.test(pt);
        const fromIsIn  = /_(?:i|in)$/.test(pf);
        const toIsIn    = /_(?:i|in)$/.test(pt);

        if (fromIsOut) return 1;   // 从 from 流出 → from→to
        if (toIsOut)   return -1;  // 从 to 流出   → to→from
        if (toIsIn)    return 1;   // 流入 to       → from→to
        if (fromIsIn)  return -1;  // 流入 from     → to→from

        return 1; // 默认 from→to
    }

    /**
     * 设备流量更新（基于区域拓扑）
     *
     * 每帧执行：
     *   main / common 区域：flow = 泵设定流量
     *   u_branch 区域：     flow = 泵流量 × (1 - 调节阀开度)
     *   l_branch 区域：     flow = 泵流量 × 调节阀开度
     *   zero 区域：         flow = 0
     */
    _updateDeviceFlows() {
        // 首次运行或拓扑未构建时调用
        if (Object.keys(this._flowZoneMap).length === 0) {
            this._buildFlowZones();
        }

        // ── 1. 泵流量（缓存引用）──
        this._refs();
        const pump = this._runningPump || this._pickRunningPump();
        const mainFlow = (pump && pump.pumpOn) ? (pump.pumpFlow != null ? pump.pumpFlow : 1) : 0;

        // ── 2. 调节阀开度（缓存引用）──
        const elecValve = this._actuatorRef;
        const pos = elecValve ? (elecValve.currentPos || 0) : 0;

        // ── 3. 各区域流量值 ──
        const zoneFlow = {
            'main':     mainFlow,
            'u_branch': mainFlow * (1 - pos),
            'l_branch': mainFlow * pos,
            'common':   mainFlow,
            'zero':     0,
        };

        // ── 4. 遍历所有设备，注入流量 ──
        const allComps = this.__allComps || Object.values(this.sys.comps);
        allComps.forEach(device => {
            if (!device.ports) return;

            // 找该设备的 pipe 端口
            const pipePorts = device.ports.filter(p => p.type === 'pipe');
            if (pipePorts.length === 0) return;

            // 用第一个 pipe 端口确定区域（同设备所有 pipe 口应在同一区域）
            const zone = this._flowZoneMap[pipePorts[0].id] || 'zero';
            const flowValue = zoneFlow[zone] !== undefined ? zoneFlow[zone] : 0;

            // 设置归一化目标流量（供 dp_flow_indicator / rotameter / impeller_flow_indicator 使用）
            if (typeof device.setFlow === 'function') {
                device._targetFlow = Math.max(0, Math.min(1, flowValue));
            }

            // 设置 device.flow 属性（供 flow_sensor / flow_transmitter 等使用）
            if ('flow' in device) {
                device.flow = flowValue;
            }
        });

        // ── 5. 管路流动动画（虚线位移 + 颜色/宽度）──
        const pipeNodes = this.sys.pipeNodes;
        if (pipeNodes && pipeNodes.length > 0) {
            const pipeConns = this.sys.conns.filter(c => c.type === 'pipe');
            // 正在运行的泵 id 集合
            const runningIds = new Set((this._pumps || []).filter(p => p.pumpOn).map(p => p.id));
            const ownerOf = this._pipeConnOwner || {};
            // 电磁阀支路开关：仅开启的支路有流动；干路需至少一个支路阀开启
            const svList = this._solenoidValves || (this._solenoidValves = Object.values(this.sys.comps).filter(c => c && c.type === 'solenoid_valve'));
            const anySvOpen = svList.some(v => v.isOpen);
            for (let i = 0; i < pipeConns.length; i++) {
                const conn = pipeConns[i];
                const lineNode = pipeNodes[i * 3];
                const flow = pipeNodes[i * 3 + 1];
                if (!flow) continue;

                const zone = this._flowZoneMap[conn.from] || this._flowZoneMap[conn.to] || 'zero';
                let flowValue = zoneFlow[zone] !== undefined ? zoneFlow[zone] : 0;

                // 停机泵的专属管路不流动
                const owner = ownerOf[`${conn.from}|${conn.to}|${conn.type}`];
                if (owner && !runningIds.has(owner)) flowValue = 0;
                // 测压支路（接压力开关/压力表）不流动
                if (this._touchesMeasure(conn)) flowValue = 0;
                // 电磁阀支路：仅阀开启的支路有流动；主路径需至少一个支路阀开启
                if (svList.length > 0) {
                    const cA = this.sys.comps[conn.from.split('_pipe_')[0]];
                    const cB = this.sys.comps[conn.to.split('_pipe_')[0]];
                    const svA = cA && cA.type === 'solenoid_valve' ? cA : null;
                    const svB = cB && cB.type === 'solenoid_valve' ? cB : null;
                    const spkA = cA && cA.special === 'sprinkler' ? cA : null;
                    const spkB = cB && cB.special === 'sprinkler' ? cB : null;
                    if (svA || svB || spkA || spkB) {
                        const valve = svA || svB
                            || (spkA && spkA.valveId && this.sys.comps[spkA.valveId])
                            || (spkB && spkB.valveId && this.sys.comps[spkB.valveId]);
                        flowValue = (valve && valve.isOpen) ? mainFlow : 0;
                    } else {
                        flowValue = anySvOpen ? mainFlow : 0;
                    }
                }
                // 当前页不可见时（如跨页）不显示流动
                const pageVisible = lineNode && lineNode.visible ? lineNode.visible() : true;

                if (flowValue > 0 && pageVisible) {
                    flow.visible(true);
                    const ratio = flowValue;
                    // 管路流动动画整体减速到原来的 2/3（水流看起来更平缓）
                    const speed = (1 + ratio * ratio * 6) * (2 / 3);
                    // 方向判定：源→目标方向为正（dashOffset 递减），反之为负
                    const dir = this._pipeFlowDirection(conn);
                    flow.dashOffset((flow.dashOffset() || 0) - speed * dir);
                    // 区域区分色：干路蓝、u支路绿、l支路橙
                    const zoneColors = { main: '#3498db', u_branch: '#27ae60', l_branch: '#e67e22' };
                    flow.stroke(zoneColors[zone] || '#3498db');
                    // 线宽 2~8px（平方放大对比）
                    flow.strokeWidth(2 + ratio * ratio * 6);
                } else {
                    flow.visible(false);
                }
            }
        }
    }

    /**
     * 处理压力在设备内部从输入端到输出端的转换
     */
    _processInternalTransfer(device, inputPortId, terminalPressures, queue) {
        const inP = terminalPressures[inputPortId];
        const deviceId = device.id;

        switch (device.type) {
            case 'teeConnector':
                device.ports.forEach(p => {
                    if (p.id !== inputPortId) {
                        terminalPressures[p.id] = inP;
                        queue.push(p.id);
                    }
                });
                break;

            case 'stopValve':
                const otherPort = device.ports.find(p => p.id !== inputPortId);
                if (otherPort) {
                    // 通用化：不硬编码气瓶 id，沿进气侧向上游查找气瓶并切换其耗气状态
                    this._setValveBottleConsuming(device, inputPortId, !!device.isOpen);
                    terminalPressures[otherPort.id] = device.isOpen ? inP : 0;
                    queue.push(otherPort.id);
                }
                break;

            case 'regulator':
                if (inputPortId.includes('_pipe_i')) {
                    const outPortId = deviceId + '_pipe_o';
                    const outP = Math.min(inP, device.setPressure || 0);
                    terminalPressures[outPortId] = outP;
                    queue.push(outPortId);
                }
                break;

            case '3valve':
                if (device.vE === false) {
                    if (inputPortId === deviceId + '_pipe_inl') {
                        const outPortId = deviceId + '_pipe_outl';
                        terminalPressures[outPortId] = device.vL ? inP : 0;
                        queue.push(outPortId);
                    } else if (inputPortId === deviceId + '_pipe_inh') {
                        const outPortId = deviceId + '_pipe_outh';
                        terminalPressures[outPortId] = device.vH ? inP : 0;
                        queue.push(outPortId);
                    }
                }
                break;

            case 'transmitter_2wire':
                if (device.special === 'press') device.press = inP;
                if (device.special === 'bubble_level') device.press = inP;
                break;

            case 'dp_flow_indicator':
            case 'rotameter':
            case 'impeller_flow_indicator':
                if (inputPortId.includes('terminal_in')) {
                    const outPort = device.ports.find(p => p.id.includes('terminal_out'));
                    if (outPort) {
                        terminalPressures[outPort.id] = inP * 0.95;
                        queue.push(outPort.id);
                    }
                }
                break;

            case 'Cooler':
                if (inputPortId.includes('_pipe_i')) {
                    const outPort = device.ports.find(p => p.id.includes('_pipe_o'));
                    if (outPort) {
                        terminalPressures[outPort.id] = inP * 0.85;
                        queue.push(outPort.id);
                    }
                }
                break;

            case 'oilFilter':
                // 滤器：按进出口压差穿透（inP - ΔP）
                if (inputPortId.includes('_pipe_i')) {
                    const outPort = device.ports.find(p => p.id.includes('_pipe_o'));
                    if (outPort) {
                        const drop = (typeof device.getDiffPressure === 'function') ? Math.max(0, device.getDiffPressure()) : 0;
                        terminalPressures[outPort.id] = Math.max(0, inP - drop);
                        queue.push(outPort.id);
                    }
                }
                break;
        }

        if (device.special === 'actuator' && device.type === 'resistor') {
            const pos = device.currentPos || 0;
            if (inputPortId.includes('_pipe_u') || inputPortId.includes('_pipe_l')) {
                const outPortId = deviceId + '_pipe_r';
                const mixRatio = inputPortId.includes('_pipe_u') ? (1 - pos) : pos;
                const prevP = terminalPressures[outPortId] || 0;
                terminalPressures[outPortId] = Math.max(prevP, inP * Math.max(mixRatio, 0.01));
                queue.push(outPortId);
            }
        }
        // 电磁阀：吸合时上下管路连通，截止时不通
        if (device.type === 'solenoid_valve') {
            if (inputPortId.startsWith(deviceId + '_pipe_')) {
                const otherPort = device.ports.find(p => p.type === 'pipe' && p.id !== inputPortId);
                if (otherPort) {
                    terminalPressures[otherPort.id] = device.isOpen ? inP : 0;
                    queue.push(otherPort.id);
                }
            }
        }
    }

    _connKey(conn) {
        return `${conn.from}|${conn.to}|${conn.type}`;
    }

    _getDeviceIdFromPort(portId) {
        return portId.split('_pipe_')[0];
    }

    // ═══════════════════════════════════════════════════════════
    // 通用化辅助
    // ═══════════════════════════════════════════════════════════

    /** 缓存泵 / 电动执行器引用（组件集合不变，只算一次） */
    _refs() {
        if (this.__refsComputed) return;
        const all = Object.values(this.sys.comps || {});
        // 支持多泵冗余：收集全部 Pump，运行时动选取「正在运行」的那台作流量源
        this._pumps = all.filter(c => c && c.type === 'Pump');
        this._pumpRef = this._pumps[0] || null;
        this._actuatorRef = all.find(c => c && c.special === 'actuator' && c.type === 'resistor') || null;
        this.__refsComputed = true;
    }

    /** 动态选取当前运行的泵（多泵冗余/自动切换时使用） */
    _pickRunningPump() {
        const pumps = this._pumps || [];
        return pumps.find(p => p && p.pumpOn) || pumps[0] || null;
    }

    /** 确定性伪随机（按端口 id 哈希到 [0,1)），避免漏气损失读数抖动 */
    _hash01(str) {
        let h = 2166136261;
        for (let i = 0; i < str.length; i++) {
            h ^= str.charCodeAt(i);
            h = Math.imul(h, 16777619);
        }
        return ((h >>> 0) % 1000) / 1000;
    }

    /**
     * 从某管路的进气侧沿管路（含三通/阀等内联导通）向上游查找气瓶。
     * 结果缓存到截止阀设备上，避免压力场每帧重算时重复 BFS。
     */
    _findUpstreamBottle(portId) {
        const sys = this.sys;
        const visited = new Set([portId]);
        const queue = [portId];
        while (queue.length) {
            const cur = queue.shift();
            const devId = this._getDeviceIdFromPort(cur);
            const dev = sys.comps[devId];
            if (dev && dev.type === 'airBottle') return dev;

            // 内联管件（三通/截止阀）内部导通
            if (dev && Array.isArray(dev.ports) && (dev.type === 'teeConnector' || dev.type === 'stopValve')) {
                dev.ports.forEach(p => {
                    if (p.type === 'pipe' && !visited.has(p.id)) { visited.add(p.id); queue.push(p.id); }
                });
            }
            // 沿管路连接扩散
            (sys.conns || []).forEach(conn => {
                if (conn.type !== 'pipe') return;
                let next = null;
                if (conn.from === cur) next = conn.to;
                else if (conn.to === cur) next = conn.from;
                if (next && !visited.has(next)) { visited.add(next); queue.push(next); }
            });
        }
        return null;
    }

    /** 设置截止阀上游气瓶的耗气状态（通用，不依赖固定 id） */
    _setValveBottleConsuming(device, inputPortId, consuming) {
        if (!device._bottleRef) device._bottleRef = this._findUpstreamBottle(inputPortId);
        if (device._bottleRef) device._bottleRef.isConsuming = consuming;
    }

    /**
     * 收集全场压力源（统一出口：气瓶 / 泵 / 执行器 / 气泡液位 / 校验仪）。
     * 供压力场 BFS 播种与源状态键共用，避免重复枚举。
     * @returns {{portId:string, pressure:number}[]}
     */
    _collectSources(allComps) {
        const list = allComps || this.__allComps || (this.__allComps = Object.values(this.sys.comps));
        const sources = [];
        list.forEach(dev => {
            if (!dev || !dev.id) return;
            if (dev.type === 'airBottle') {
                sources.push({ portId: `${dev.id}_pipe_o`, pressure: dev.pressure || 0 });
            } else if (dev.type === 'Pump' && dev.pumpOn) {
                // 泵排出压力：优先用组件给出的 outPressure（如滑油泵：入口 -0.1 + 加压 0.6 = 0.5 MPa）
                const outP = (typeof dev.getOutPressure === 'function') ? dev.getOutPressure()
                    : (dev.outPressure !== undefined ? dev.outPressure : 0.4);
                sources.push({ portId: `${dev.id}_pipe_o`, pressure: outP || 0 });
                // 吸入口压力（若有）：滑油泵吸入侧为负压（-0.1 MPa）
                if (dev.inPressure !== undefined && isFinite(dev.inPressure)) {
                    sources.push({ portId: `${dev.id}_pipe_i`, pressure: dev.inPressure });
                }
            } else if (dev.special === 'actuator') {
                sources.push({ portId: `${dev.id}_pipe_o`, pressure: dev.outPress || 0 });
            } else if (dev.special === 'bubble_level') {
                sources.push({ portId: `${dev.id}_pipe_o`, pressure: dev.backPress / 1000 || 0 });
            } else if (dev.type === 'calibrator' && dev.activePanel === 'SOURCE' && dev.sourceMode === 'SRC_PRESSURE') {
                sources.push({ portId: `${dev.id}_pipe_o`, pressure: dev.sourceValue / 1000 || 0 });
            }
        });
        return sources;
    }

    /**
     * 压力源状态键：源端口与压力值组成的签名。
     * 与连接拓扑键拼接后用于判断是否需要重算压力场。
     */
    _computeSourceKey() {
        // 量化到 1e-3 MPa：气瓶缓慢耗气时避免每帧触发全场 BFS（读数步进 ≤ 显示精度）
        return this._collectSources()
            .map(s => `${s.portId}=${(s.pressure || 0).toFixed(3)}`)
            .sort()
            .join(';');
    }

    /**
     * 压缩机充气：运转中的压缩机，其排气口（_pipe_o）经管路（可穿过三通等
     * 无源管件）连到某气瓶时，逐帧为该气瓶充气（充气量取设备 `refillRate`）。
     */
    _updateCompressors() {
        const allComps = this.__allComps || (this.__allComps = Object.values(this.sys.comps));
        for (const dev of allComps) {
            if (!dev || dev.type !== 'airCompressor' || !dev.running) continue;
            const rate = dev.refillRate !== undefined ? dev.refillRate : 0.001;
            if (rate <= 0) continue;
            const bottle = this._findConnectedBottle(`${dev.id}_pipe_o`);
            if (bottle) bottle.refill(rate);
        }
    }

    /**
     * 从起始端口沿管路搜索相连的气瓶（允许经三通等无源管件间接连接）。
     * @returns {object|null} 气瓶组件
     */
    _findConnectedBottle(startPort) {
        const visited = new Set();
        const queue = [startPort];
        while (queue.length) {
            const cur = queue.shift();
            if (visited.has(cur)) continue;
            visited.add(cur);

            const devId = this._getDeviceIdFromPort(cur);
            const dev = this.sys.comps[devId];

            // 到达气瓶即为目标
            if (dev && dev.type === 'airBottle' && typeof dev.refill === 'function') return dev;

            // 沿管路连接扩散
            (this.sys.conns || []).forEach(conn => {
                if (conn.type !== 'pipe') return;
                let next = null;
                if (conn.from === cur) next = conn.to;
                else if (conn.to === cur) next = conn.from;
                if (next && !visited.has(next)) queue.push(next);
            });

            // 无源管件（三通）内部导通：把同设备其它 pipe 端口入队；
            // 截止阀/单向截止阀在开启时同样导通，需一并穿越，否则压缩机无法
            // 经打开的截止阀找到下游气瓶、无法充气。
            if (dev && (dev.type === 'teeConnector' || (dev.type === 'stopValve' && dev.isOpen)) && Array.isArray(dev.ports)) {
                dev.ports.forEach(p => {
                    if (p.type === 'pipe' && !visited.has(p.id)) queue.push(p.id);
                });
            }
        }
        return null;
    }

    /** 公共接口：查询某气路端口当前压力（MPa） */
    getPressAt(portId) {
        return this.terminalPressures ? (this.terminalPressures[portId] || 0) : 0;
    }

    _computeTopologyKey() {
        // 连线列表（规范化后排序）
        const conns = (this.sys.conns || []).map(c => `${c.from}|${c.to}|${c.type}`).sort().join(';');

        // 关键设备状态：影响连通性的那些（截止阀、三通、三位阀等）
        const parts = [];
        Object.values(this.sys.comps || {}).forEach(dev => {
            if (!dev || !dev.id) return;
            if (dev.type === 'stopValve') {
                parts.push(`${dev.id}:stop:${!!dev.isOpen}`);
            } else if (dev.type === '3valve') {
                parts.push(`${dev.id}:3valve:e=${!!dev.vE},h=${!!dev.vH},l=${!!dev.vL}`);
            } else if (dev.type === 'airCompressor') {
                parts.push(`${dev.id}:compressor:state=${!!dev.running},p=${dev.pressure || 0}`);
            } else if (dev.type === 'regulator') {
                parts.push(`${dev.id}:regulator:setP=${dev.setPressure || 0}`);
            } else if (dev.type === 'calibrator') {
                parts.push(`${dev.id}:calibrator:upMode=${dev.upMode},sourceMode=${dev.sourceMode},sourceValue=${dev.sourceValue}`);
            } else if (dev.special === 'bubble_level') {
                parts.push(`${dev.id}:bubble_level:backPress=${dev.backPress}`);
            } else if (dev.type === 'solenoid_valve') {
                parts.push(`${dev.id}:sv:open=${!!dev.isOpen}`);
            } else if (dev.type === 'Pump') {
                parts.push(`${dev.id}:pumpOn=${!!dev.pumpOn},flow=${dev.pumpFlow != null ? dev.pumpFlow : 1}`);
            } else if (dev.type === 'engine') {
                parts.push(`${dev.id}:engOn=${!!dev.engOn}`);
            }
            // 电动阀/执行器位置 -> 影响流道拓扑（使求解器在阀位变化时重新同步）
            if (dev.special === 'actuator' && typeof dev.currentPos === 'number') {
                parts.push(`${dev.id}:pos=${dev.currentPos.toFixed(3)}`);
            }
        });

        return conns + '|' + parts.sort().join(';');
    }

    _pressuresChanged(prev, curr) {
        const eps = this.pressureEps || 1e-4;
        const keys = new Set([...Object.keys(prev || {}), ...Object.keys(curr || {})]);
        for (const k of keys) {
            const pv = prev[k] || 0;
            const cv = curr[k] || 0;
            if (Math.abs(pv - cv) > eps) return true;
        }
        return false;
    }
}
